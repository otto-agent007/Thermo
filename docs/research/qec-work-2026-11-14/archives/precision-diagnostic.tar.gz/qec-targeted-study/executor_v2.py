"""Short synchronous jobs. Does not control or retire any historical runner.

Use one trusted single-process scientific command per batch. Never auto-steal a
lease: interruption reserves the entire limit until termination is established.
Results are published only with a receipt. Linux/POSIX local filesystem required.
"""
import ctypes,fcntl,hashlib,json,math,os,resource,signal,subprocess,time,uuid
from pathlib import Path

def atomic(path,obj):
 path=Path(path);tmp=path.with_name(path.name+'.tmp-'+uuid.uuid4().hex)
 with tmp.open('x') as f:
  json.dump(obj,f,indent=2);f.flush();os.fsync(f.fileno())
 os.replace(tmp,path)
 fd=os.open(path.parent,os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)

def initialize(root,total,case_caps):
 root=Path(root);root.mkdir(parents=True,exist_ok=True)
 with (root/'lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  if (root/'ledger.json').exists():raise FileExistsError('ledger already initialized')
  if total<=0 or any(x<=0 for x in case_caps.values()):raise ValueError('invalid budgets')
  atomic(root/'ledger.json',{'total_limit':total,'case_limits':case_caps,'entries':{},'protocol':'inherited-kernel-lock-v2'})

def _run_once(root,case,batch_id,command,cpu_limit=20,wall_limit=25,memory_bytes=3*2**30,input_hashes=None,caller_cpu_seconds=0):
 supervisor_start=time.process_time()
 root=Path(root).resolve()
 if not batch_id or Path(batch_id).name!=batch_id or batch_id in ('.','..'):raise ValueError('invalid batch identifier')
 if cpu_limit!=int(cpu_limit) or wall_limit!=int(wall_limit) or cpu_limit<=0 or wall_limit<=0:raise ValueError('positive integer limits required')
 input_hashes=input_hashes or {}
 for path,digest in input_hashes.items():
  if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=digest:raise ValueError('input/source hash mismatch:'+path)
 spec={'input_hashes':input_hashes,'case':case,'batch':batch_id,'command':command,'cpu_limit':cpu_limit,'wall_limit':wall_limit,'memory_bytes':memory_bytes}
 digest=hashlib.sha256(json.dumps(spec,sort_keys=True).encode()).hexdigest()
 with (root/'lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  ledger=json.loads((root/'ledger.json').read_text());entries=ledger['entries']
  if batch_id in entries:
   old=entries[batch_id]
   if old['spec_sha256']!=digest:raise ValueError('batch id belongs to different specification')
   receipt=root/'batches'/batch_id/'receipt.json'
   if receipt.exists():
    saved=json.loads(receipt.read_text())
    if saved['token']!=old['token']:raise RuntimeError('receipt ownership mismatch')
    if saved['status']=='completed' and hashlib.sha256((receipt.parent/'output').read_bytes()).hexdigest()!=saved['output_sha256']:raise RuntimeError('output integrity failure')
    old.update(state=saved['status'],charged_cpu_seconds=saved['charged_cpu_seconds']);atomic(root/'ledger.json',ledger)
    if (root/'lease.json').exists():
     lease=json.loads((root/'lease.json').read_text())
     if lease.get('token')!=old['token']:raise RuntimeError('different lease remains active')
     (root/'lease.json').unlink()
    return saved
   raise RuntimeError('unsettled batch; establish termination before explicit recovery')
  if (root/'lease.json').exists():raise RuntimeError('unsettled lease; no automatic takeover')
  if case not in ledger['case_limits']:raise ValueError('unknown case')
  total=sum(x['charged_cpu_seconds'] for x in entries.values());used=sum(x['charged_cpu_seconds'] for x in entries.values() if x['case']==case)
  reservation=cpu_limit+1
  if total+reservation>ledger['total_limit'] or used+reservation>ledger['case_limits'][case]:raise ValueError('CPU reservation exceeds remaining budget')
  folder=root/'batches'/batch_id
  if folder.exists():os.rename(folder,folder.with_name(folder.name+'--uncommitted-'+uuid.uuid4().hex))
  folder.mkdir(parents=True,exist_ok=False)
  atomic(folder/'spec.json',spec)
  token=uuid.uuid4().hex
  entry={'case':case,'spec_sha256':digest,'charged_cpu_seconds':reservation,'state':'reserved','token':token,'reserved_at':time.time(),'wall_limit':wall_limit}
  entries[batch_id]=entry;atomic(root/'ledger.json',ledger)
  atomic(root/'lease.json',{'token':token,'batch':batch_id,'supervisor_pid':os.getpid(),'inherited_kernel_lock':True,'wall_limit':wall_limit,'state':'reserved'})
  output=folder/'output.pending';argv=[x.replace('{output}',str(output)) for x in command]
  parent_pid=os.getpid()
  def limits():
   # Linux parent-death signal prevents an orphan after supervisor termination.
   libc=ctypes.CDLL(None,use_errno=True)
   if libc.prctl(1,signal.SIGKILL,0,0,0)!=0:raise OSError(ctypes.get_errno(),'PR_SET_PDEATHSIG')
   if os.getppid()!=parent_pid:os.kill(os.getpid(),signal.SIGKILL)
   resource.setrlimit(resource.RLIMIT_AS,(memory_bytes,memory_bytes));resource.setrlimit(resource.RLIMIT_CPU,(cpu_limit,cpu_limit))
   signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.alarm(wall_limit)
  start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN);p=None;error=None
  env=os.environ.copy()
  for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):env[key]='1'
  try:
   with (folder/'stdout.log').open('wb') as stdout,(folder/'stderr.log').open('wb') as stderr:
    p=subprocess.Popen(argv,stdout=stdout,stderr=stderr,env=env,start_new_session=True,preexec_fn=limits,pass_fds=(lock.fileno(),))
    atomic(root/'lease.json',{'token':token,'batch':batch_id,'supervisor_pid':os.getpid(),'inherited_kernel_lock':True,'child_pid':p.pid,'wall_limit':wall_limit,'started_at':time.time()})
    try:p.wait(timeout=wall_limit+2)
    except subprocess.TimeoutExpired:
     os.killpg(p.pid,signal.SIGKILL);p.wait();error='supervisor wall deadline'
  except Exception as exc:
   error=repr(exc)
   if p is not None and p.poll() is None:
    os.killpg(p.pid,signal.SIGKILL);p.wait()
  after=resource.getrusage(resource.RUSAGE_CHILDREN)
  measured=(after.ru_utime+after.ru_stime)-(before.ru_utime+before.ru_stime)
  # Round up measured usage, and retain full reservation for signal termination.
  supervisor_cpu=time.process_time()-supervisor_start+caller_cpu_seconds
  measured_total=math.ceil((measured+max(1,supervisor_cpu))*1000)/1000
  charge=max(reservation,measured_total) if p is None or p.returncode is None or p.returncode<0 else measured_total
  lease=json.loads((root/'lease.json').read_text())
  if lease.get('token')!=token:raise RuntimeError('fenced: ownership changed, no publication')
  success=p is not None and p.returncode==0 and output.is_file() and error is None
  if success:
   with output.open('rb') as f:os.fsync(f.fileno())
   os.replace(output,folder/'output')
  receipt={'status':'completed' if success else 'failed','batch':batch_id,'case':case,'returncode':None if p is None else p.returncode,'error':error,'wall_seconds':time.monotonic()-start,'measured_cpu_seconds':measured,'supervisor_cpu_seconds':supervisor_cpu,'charged_cpu_seconds':charge,'token':token,'output_sha256':hashlib.sha256((folder/'output').read_bytes()).hexdigest() if success else None}
  atomic(folder/'receipt.json',receipt)
  entry.update(state=receipt['status'],charged_cpu_seconds=charge);atomic(root/'ledger.json',ledger)
  (root/'lease.json').unlink()
  fd=os.open(root,os.O_DIRECTORY)
  try:os.fsync(fd)
  finally:os.close(fd)
  return receipt

def charge_overhead(root,case,identity,cpu_seconds):
 """Record measured orchestration work; caller also accounts interpreter startup."""
 root=Path(root);cost=math.ceil(cpu_seconds*1000)/1000
 if not math.isfinite(cost) or cost<0:raise ValueError('invalid overhead')
 with (root/'lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  if (root/'lease.json').exists():raise RuntimeError('cannot settle overhead during unsettled job')
  ledger=json.loads((root/'ledger.json').read_text());key='overhead:'+identity
  if key in ledger['entries']:return ledger['entries'][key]
  entry={'case':case,'charged_cpu_seconds':cost,'state':'measured_overhead'}
  ledger['entries'][key]=entry;atomic(root/'ledger.json',ledger)
  if sum(x['charged_cpu_seconds'] for x in ledger['entries'].values())>ledger['total_limit'] or sum(x['charged_cpu_seconds'] for x in ledger['entries'].values() if x['case']==case)>ledger['case_limits'][case]:raise RuntimeError('budget exhausted by measured overhead; no more work permitted')
  return entry


def reconcile(root):
 """v2 only: same flock proves protected supervisor/child have both exited."""
 root=Path(root)
 with (root/'lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  ledger=json.loads((root/'ledger.json').read_text())
  pending=[(b,e) for b,e in ledger['entries'].items() if e.get('state')=='reserved']
  lease=json.loads((root/'lease.json').read_text()) if (root/'lease.json').exists() else None
  if not pending and not lease:return {'status':'no_unsettled_lease'}
  if ledger.get('protocol')!='inherited-kernel-lock-v2' or (lease and lease.get('inherited_kernel_lock') is not True):raise RuntimeError('legacy lease requires external termination proof')
  if lease and not any(b==lease['batch'] for b,e in pending):pending.append((lease['batch'],ledger['entries'][lease['batch']]))
  outcomes=[]
  for batch,entry in pending:
   folder=root/'batches'/batch
   if lease and batch==lease['batch'] and entry['token']!=lease['token']:raise RuntimeError('ownership mismatch')
   if (folder/'receipt.json').exists():
    r=json.loads((folder/'receipt.json').read_text())
    if r['token']!=entry['token']:raise RuntimeError('receipt ownership mismatch')
    if r['status']=='completed' and hashlib.sha256((folder/'output').read_bytes()).hexdigest()!=r['output_sha256']:raise RuntimeError('completed output hash mismatch')
   else:
    if (folder/'output').exists():
     os.rename(folder/'output',folder/('output.uncommitted-'+uuid.uuid4().hex));fd=os.open(folder,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
    r={'status':'interrupted','batch':batch,'case':entry['case'],'returncode':None,'error':'supervisor interrupted; inherited kernel lock release proves no surviving protected child','wall_seconds':entry['wall_limit'],'measured_cpu_seconds':None,'charged_cpu_seconds':entry['charged_cpu_seconds'],'token':entry['token'],'output_sha256':None}
    atomic(folder/'receipt.json',r)
   entry.update(state=r['status'],charged_cpu_seconds=r['charged_cpu_seconds']);outcomes.append({'batch':batch,'outcome':r['status']})
  atomic(root/'ledger.json',ledger)
  if lease:
   (root/'lease.json').unlink();fd=os.open(root,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
  return {'status':'reconciled','outcomes':outcomes}

def run_batch(root,case,batch_id,command,cpu_limit=20,wall_limit=25,memory_bytes=3*2**30,input_hashes=None,caller_cpu_seconds=0):
 reconcile(root)
 root=Path(root);ledger=json.loads((root/'ledger.json').read_text());attempt=0
 while True:
  ident=batch_id if attempt==0 else batch_id+'--attempt-'+str(attempt).zfill(3)
  entry=ledger['entries'].get(ident)
  if entry is None or entry['state'] not in ('interrupted','failed'):break
  # Interrupted attempts retain their reservation and artifacts. Exact frozen
  # scientific work only; caller cannot change command/input under same job ID.
  spec=json.loads((root/'batches'/ident/'spec.json').read_text())
  if any(spec[k]!=v for k,v in {'case':case,'command':command,'cpu_limit':cpu_limit,'wall_limit':wall_limit,'memory_bytes':memory_bytes,'input_hashes':input_hashes or {}}.items()):raise ValueError('interrupted job specification changed')
  attempt+=1
  if attempt>2:raise RuntimeError('three failed/interrupted attempts; explicit diagnosis required, artifacts retained')
 return _run_once(root,case,ident,command,cpu_limit,wall_limit,memory_bytes,input_hashes,caller_cpu_seconds)
