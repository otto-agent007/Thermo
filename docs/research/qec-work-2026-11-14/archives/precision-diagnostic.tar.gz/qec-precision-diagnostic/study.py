"""Fixed tiny-model diagnostic with independent primal truth and frozen proxies."""
import hashlib,json,random,sys,time,resource
from pathlib import Path
from fractions import Fraction as F
from interval_reference import evaluate
HOME=Path(__file__).resolve().parent
sys.path.insert(0,str(HOME.parent/'qec-targeted-study'))
from executor_v2 import atomic,initialize,run_batch,charge_overhead

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pair(x):x=F(x);return [x.numerator,x.denominator]
def fixtures():
 def f(name,m,masks,p):return dict(name=name,split='stress',m=m,masks=masks,p=[pair(x) for x in p])
 out=[f('tie',1,[2],[F(1,2)]),f('near_tie',1,[2],[F(1,2)+F(1,10**30)]),
 f('rare40',1,[1,2],[F(1,10**40),F(1,3)]),f('forced',2,[1,2,4,3],[0,1,F(1,4),1]),
 f('dependent',2,[3,7],[F(1,100),F(2,25)]),f('null',1,[0,1,2],[F(1,5),F(1,7),F(1,3)]),
 f('empty',1,[],[]),f('rare_competing',1,[1,3],[F(1,10**20),F(1,10**20)+F(1,10**50)]),
 f('binary64',2,[1,2,3,4,7],[F.from_float(.01)]*5),f('rare100',1,[1,2],[F(1,10**100),F(1,3)])]
 for split,seeds in [('development',range(901,907)),('heldout',range(1901,1907))]:
  for seed in seeds:
   rng=random.Random(seed);ps=[F(1,100),F(2,25),F(1,4)]
   out.append(dict(name=f'{split}_{seed}',split=split,m=3,masks=[rng.randrange(1,16) for _ in range(10)],p=[pair(ps[(seed+i)%3]) for i in range(10)]))
 return out

def oracle(f):
 # Primal direct fault enumeration, not Fourier or interval arithmetic.
 p=[F(*x) for x in f['p']];classes=[[] for _ in range(2**(f['m']+1))]
 for bits in range(2**len(p)):
  mass=F(1);y=0
  for j,(prob,mask) in enumerate(zip(p,f['masks'])):
   if bits>>j&1:mass*=prob;y^=mask
   else:mass*=1-prob
  if mass:classes[y].append(mass)
 return [sum(v,F(0)) for v in classes],[sorted(v,reverse=True) for v in classes]

def worker(config,name,output):
 start=time.process_time();cfg=json.loads(Path(config).read_text());f=next(x for x in cfg['fixtures'] if x['name']==name)
 for p,h in cfg['hashes'].items():
  if sha(p)!=h:raise ValueError('source hash changed')
 truth,lists=oracle(f);precisions=[];enclosed=True;targets=[]
 for precision in cfg['precisions']:
  out=evaluate(f,precision);record={'precision':precision,'mass':[[str(x) for x in v] for v in out['mass']],'posterior':[None if v is None else [str(x) for x in v] for v in out['posterior']]}
  for y,v in enumerate(out['mass']):enclosed &= F(v[0])<=truth[y]<=F(v[1])
  ok=True
  for s,v in enumerate(out['posterior']):
   den=truth[s]+truth[s+2**f['m']]
   if not den:continue
   t=truth[s]/den
   if v is None:ok=False;continue
   enclosed &= F(v[0])<=t<=F(v[1]);ok &= F(v[1])-F(v[0])<=F(1,10**10)
  record.update(enclosure_pass=bool(enclosed),all_possible_posteriors_narrow=bool(ok));precisions.append(record)
  if ok:targets.append(precision)
  if not enclosed:raise ArithmeticError('enclosure violation')
 proxies=[]
 for s in range(2**f['m']):
  a,b=truth[s],truth[s+2**f['m']];den=a+b
  if not den:continue
  post=a/den;item={'syndrome':s,'syndrome_mass':pair(den),'posterior0':pair(post),'truth_close':F(9,20)<=post<=F(11,20)}
  for k in (1,4):
   x=sum(lists[s][:k],F(0));y=sum(lists[s+2**f['m']][:k],F(0));margin=abs(x-y)/(x+y)
   item[f'top{k}']={'margin':pair(margin),'close':margin<=F(1,10),'prediction':None if x==y else int(x<y)}
  p1,p4=item['top1']['prediction'],item['top4']['prediction'];item['disagreement']=p1 is not None and p4 is not None and p1!=p4
  proxies.append(item)
 atomic(output,{'name':name,'fixture':f,'truth_mass':[pair(x) for x in truth],'precisions':precisions,'minimum_narrow_precision':min(targets) if targets else None,'gate_pass':bool(enclosed and targets),'proxies':proxies,'cpu_seconds':time.process_time()-start,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})

def setup():
 cfgpath=HOME/'manifest.json'
 cfg={'fixtures':fixtures(),'precisions':[16,32,64,128],'total_cpu':300,'case_cpu':33,'cpu_limit':10,'wall_limit':30,'memory_bytes':256*2**20,
 'hashes':{str(p.resolve()):sha(p) for p in [HOME/'PROTOCOL.md',HOME/'interval_reference.py',Path(__file__),HOME.parent/'qec-targeted-study/executor_v2.py',Path(sys.executable).resolve()]}}
 if cfgpath.exists():
  if json.loads(cfgpath.read_text())!=cfg:raise ValueError('frozen manifest differs')
 else:atomic(cfgpath,cfg)
 if not (HOME/'execution/ledger.json').exists():initialize(HOME/'execution',300,{f['name']:33 for f in cfg['fixtures']})
 return cfgpath

def step():
 begin=time.process_time();cfgpath=setup();cfg=json.loads(cfgpath.read_text());results=[]
 for p,h in cfg['hashes'].items():
  if sha(p)!=h:raise ValueError('frozen source changed')
 for f in cfg['fixtures']:
  if f['split']!='stress' and not all(r['gate_pass'] for r in results if r['fixture']['split']=='stress'):raise RuntimeError('stage A rejected; no Stage B')
  name=f['name'];existing=[]
  for folder in (HOME/'execution/batches').glob(name+'*') if (HOME/'execution/batches').exists() else []:
   receipt=folder/'receipt.json'
   if receipt.exists():
    r=json.loads(receipt.read_text())
    if r['case']==name and r['status']=='completed':
     spec=json.loads((folder/'spec.json').read_text())
     if spec['input_hashes']!={**cfg['hashes'],str(cfgpath):sha(cfgpath)} or spec['case']!=name:raise ValueError('saved job provenance mismatch')
     if sha(folder/'output')!=r['output_sha256']:raise ValueError('corrupt output')
     existing.append(folder/'output')
  if existing:
   if len(existing)!=1:raise ValueError('duplicate completed case')
   results.append(json.loads(existing[0].read_text()));continue
  r=run_batch(HOME/'execution',name,name,[sys.executable,str(Path(__file__).resolve()),'worker',str(cfgpath),name,'{output}'],10,30,256*2**20,input_hashes={**cfg['hashes'],str(cfgpath):sha(cfgpath)},caller_cpu_seconds=time.process_time())
  print(json.dumps({'case':name,'receipt':r}),flush=True);return
 ledger=json.loads((HOME/'execution/ledger.json').read_text());charge_overhead(HOME/'execution',cfg['fixtures'][-1]['name'],'final-'+str(len(ledger['entries'])),time.process_time())
 atomic(HOME/'RESULTS.json',{'manifest_sha256':sha(cfgpath),'results':results,'complete':True})
 print('COMPLETE',flush=True)
if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='worker':worker(*sys.argv[2:])
 else:step()
