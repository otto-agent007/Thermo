import json,pathlib
from fractions import Fraction as F
R=pathlib.Path(__file__).resolve().parents[1]
x=json.loads((R/'RESULTS.json').read_text())['results'];summary={}
for split in ('development','heldout'):
 rows=[p for r in x if r['fixture']['split']==split for p in r['proxies']]
 d={'syndromes':len(rows),'true_close':sum(p['truth_close'] for p in rows),'methods':{}}
 for method in ('top1','top4','disagreement'):
  c={k:0 for k in ['tp','fp','fn','tn']};w={k:F(0) for k in c}
  for p in rows:
   pred=p[method] if method=='disagreement' else p[method]['close']; truth=p['truth_close']
   key=('t' if truth else 'f')+'p' if pred else ('f' if truth else 't')+'n'
   c[key]+=1;w[key]+=F(*p['syndrome_mass'])/6
  d['methods'][method]={'counts':c,'precision':None if not c['tp']+c['fp'] else c['tp']/(c['tp']+c['fp']),'recall':None if not c['tp']+c['fn'] else c['tp']/(c['tp']+c['fn']),'weighted_counts':{k:float(v) for k,v in w.items()}}
 summary[split]=d
summary['mass_enclosures']=sum(len(p['mass']) for r in x for p in r['precisions'])
summary['posterior_enclosures']=sum(sum(v is not None for v in p['posterior']) for r in x for p in r['precisions'])
summary['precision_first_narrow']={r['name']:r['minimum_narrow_precision'] for r in x}
summary['worker_cpu_seconds']=sum(r['cpu_seconds'] for r in x)
summary['max_worker_rss_kib']=max(r['peak_rss_kib'] for r in x)
ledger=json.loads((R/'execution/ledger.json').read_text());summary['charged_cpu_seconds_after_reuse']=sum(e['charged_cpu_seconds'] for e in ledger['entries'].values())
(R/'audit/SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
