"""Independent primal enumeration audit. Imports no study/reference arithmetic."""
import hashlib, itertools, json, pathlib, resource, time
from fractions import Fraction
ROOT=pathlib.Path(__file__).resolve().parents[1]

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def exact(f):
    width=2**(f['m']+1)
    buckets=[[] for _ in range(width)]
    for bits in itertools.product((0,1),repeat=len(f['p'])):
        output=0; weight=Fraction(1)
        for bit,mask,ratio in zip(bits,f['masks'],f['p']):
            probability=Fraction(*ratio)
            weight*=probability if bit else 1-probability
            if bit: output ^=mask
        if weight: buckets[output].append(weight)
    return [sum(v,Fraction(0)) for v in buckets], [sorted(v,reverse=True) for v in buckets]

def main():
    begin=time.process_time()
    cfg=json.loads((ROOT/'manifest.json').read_text())
    result=json.loads((ROOT/'RESULTS.json').read_text())
    assert result['manifest_sha256']==digest(ROOT/'manifest.json')
    for file,value in cfg['hashes'].items(): assert digest(pathlib.Path(file))==value, file
    assert len(result['results'])==len(cfg['fixtures'])==22
    assert len({r['name'] for r in result['results']})==22
    checks=0; narrow={}; cases=[]
    for f,r in zip(cfg['fixtures'],result['results']):
        assert r['fixture']==f and r['name']==f['name']
        mass,buckets=exact(f); assert sum(mass)==1
        assert mass==[Fraction(*v) for v in r['truth_mass']]
        first=None
        assert [p['precision'] for p in r['precisions']]==cfg['precisions']
        for p in r['precisions']:
            for truth,interval in zip(mass,p['mass']):
                lo,hi=map(Fraction,interval); assert lo<=truth<=hi; checks+=1
            valid=True
            for s,interval in enumerate(p['posterior']):
                den=mass[s]+mass[s+2**f['m']]
                if den==0:
                    assert interval is None
                    continue
                if interval is None: valid=False;continue
                lo,hi=map(Fraction,interval);truth=mass[s]/den
                assert 0<=lo<=truth<=hi<=1;checks+=1
                if hi-lo>Fraction(1,10**10): valid=False
            assert p['enclosure_pass'] is True
            assert p['all_possible_posteriors_narrow']==valid
            if valid and first is None: first=p['precision']
        assert r['minimum_narrow_precision']==first
        assert r['gate_pass']==(first is not None)
        narrow[f['name']]=first
        actual=[s for s in range(2**f['m']) if mass[s]+mass[s+2**f['m']]]
        assert [x['syndrome'] for x in r['proxies']]==actual
        for x in r['proxies']:
            s=x['syndrome'];den=mass[s]+mass[s+2**f['m']];p0=mass[s]/den
            assert Fraction(*x['syndrome_mass'])==den
            assert Fraction(*x['posterior0'])==p0
            assert x['truth_close']==(Fraction(9,20)<=p0<=Fraction(11,20))
            pred=[]
            for k in [1,4]:
                a=sum(buckets[s][:k],Fraction(0));b=sum(buckets[s+2**f['m']][:k],Fraction(0))
                margin=abs(a-b)/(a+b); prediction=None if a==b else int(a<b)
                got=x[f'top{k}']; assert Fraction(*got['margin'])==margin
                assert got['close']==(margin<=Fraction(1,10)) and got['prediction']==prediction
                pred.append(prediction)
            assert x['disagreement']==(None not in pred and pred[0]!=pred[1])
        cases.append({'name':f['name'],'possible_syndromes':len(actual),'minimum_narrow_precision':first})
    ledger=json.loads((ROOT/'execution/ledger.json').read_text());charge=sum(e['charged_cpu_seconds'] for e in ledger['entries'].values())
    assert charge<=cfg['total_cpu']
    for name,cap in ledger['case_limits'].items(): assert sum(e['charged_cpu_seconds'] for e in ledger['entries'].values() if e['case']==name)<=cap
    complete=[]
    for folder in (ROOT/'execution/batches').iterdir():
        receipt=json.loads((folder/'receipt.json').read_text());spec=json.loads((folder/'spec.json').read_text())
        assert spec['cpu_limit']==cfg['cpu_limit'] and spec['wall_limit']==cfg['wall_limit'] and spec['memory_bytes']==cfg['memory_bytes']
        assert spec['input_hashes'][str(ROOT/'manifest.json')]==digest(ROOT/'manifest.json')
        if receipt['status']=='completed':
            assert receipt['returncode']==0 and receipt['output_sha256']==digest(folder/'output')
            assert receipt['measured_cpu_seconds']<=cfg['cpu_limit']+0.1
            complete.append(receipt['case'])
    assert sorted(complete)==sorted(f['name'] for f in cfg['fixtures'])
    assert not (ROOT/'execution/lease.json').exists()
    report={'pass':True,'independence':'Primal itertools enumeration with Fraction; no imports of implementation or study oracle','models':len(cases),'enclosure_checks':checks,'cases':cases,'charged_execution_cpu_seconds':charge,'audit_cpu_seconds':time.process_time()-begin,'audit_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'limitations':['Tiny synthetic models only','Does not certify d5 tensor backend or physical noise accuracy','Exact top-k enumeration is not deployable decoder latency']}
    (ROOT/'audit/RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
