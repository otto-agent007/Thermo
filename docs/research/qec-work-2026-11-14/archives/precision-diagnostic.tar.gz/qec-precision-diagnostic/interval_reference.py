"""Tiny full signed Fourier sum with directed Decimal interval arithmetic.
No oracle import; no float intermediates; not a scalable tensor backend.
"""
from decimal import Decimal, Context as DC, ROUND_FLOOR, ROUND_CEILING
from fractions import Fraction

class Context:
 def __init__(self,precision):
  if not isinstance(precision,int) or precision<2:raise ValueError('invalid precision')
  self.lo=DC(prec=precision,rounding=ROUND_FLOOR,Emin=-999999,Emax=999999)
  self.hi=DC(prec=precision,rounding=ROUND_CEILING,Emin=-999999,Emax=999999)
 def rational(self,x):
  x=Fraction(x);a,b=Decimal(x.numerator),Decimal(x.denominator)
  return self.lo.divide(a,b),self.hi.divide(a,b)
 def add(self,a,b):return self.lo.add(a[0],b[0]),self.hi.add(a[1],b[1])
 def sub(self,a,b):return self.lo.subtract(a[0],b[1]),self.hi.subtract(a[1],b[0])
 def mul(self,a,b):
  return min(self.lo.multiply(x,y) for x in a for y in b),max(self.hi.multiply(x,y) for x in a for y in b)
 def divide_positive(self,a,b):
  if a[0]<0 or b[0]<=0:raise ValueError('positive denominator and nonnegative numerator required')
  return self.lo.divide(a[0],b[1]),self.hi.divide(a[1],b[0])

def posterior(c,a,b):
 # Use structural nonnegativity, never narrow outside known [0,1] mass domain.
 zero,one=Decimal(0),Decimal(1)
 a=(max(zero,a[0]),min(one,a[1]));b=(max(zero,b[0]),min(one,b[1]))
 if a[0]>a[1] or b[0]>b[1]:raise ValueError('mass interval contradicts nonnegativity')
 total=c.add(a,b)
 if total[0]<=0:return None
 # Monotonic a/(a+b), with distinct extremal denominators, avoids loose ratio.
 lower_den=c.hi.add(a[0],b[1]);upper_den=c.lo.add(a[1],b[0])
 return c.lo.divide(a[0],lower_den),c.hi.divide(a[1],upper_den)

def evaluate(fixture,precision):
 m=fixture['m'];masks=fixture['masks'];probs=[Fraction(*v) for v in fixture['p']]
 if not isinstance(m,int) or not 0<=m<=8 or len(masks)!=len(probs) or len(masks)>16:raise ValueError('invalid dimensions')
 if any(not isinstance(a,int) or not 0<=a<2**(m+1) for a in masks) or any(not 0<=p<=1 for p in probs):raise ValueError('invalid input')
 c=Context(precision);one=c.rational(1);two=c.rational(2)
 q=[c.sub(one,c.mul(two,c.rational(p))) for p in probs]
 values=[]
 for u in range(2**(m+1)):
  v=one
  for mask,qq in zip(masks,q):
   if (u&mask).bit_count()%2:v=c.mul(v,qq)
  values.append(v)
 # Unnormalized Walsh-Hadamard transform is the signed Fourier sum.
 step=1
 while step<len(values):
  for start in range(0,len(values),2*step):
   for j in range(start,start+step):
    a,b=values[j],values[j+step];values[j],values[j+step]=c.add(a,b),c.sub(a,b)
  step*=2
 scale=c.rational(Fraction(1,len(values)));values=[c.mul(v,scale) for v in values]
 return {'mass':values,'posterior':[posterior(c,values[s],values[s+2**m]) for s in range(2**m)]}
