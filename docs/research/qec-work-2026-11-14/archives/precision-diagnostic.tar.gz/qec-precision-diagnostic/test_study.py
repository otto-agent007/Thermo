import unittest,tempfile,json
from pathlib import Path
from unittest.mock import patch
import study
class StudyTests(unittest.TestCase):
 def test_fixed_fixture_scope(self):
  fs=study.fixtures();self.assertEqual(len(fs),22);self.assertEqual(sum(f['split']=='stress' for f in fs),10)
  self.assertEqual(sum(f['split']=='heldout' for f in fs),6);self.assertTrue(all(len(f['p'])<=10 for f in fs))
 def test_primal_tie(self):
  f=study.fixtures()[0];mass,lists=study.oracle(f)
  self.assertEqual(sum(mass),1);self.assertEqual(mass[0],mass[2]);self.assertEqual(mass[1],0)
 def test_forced_possible_support(self):
  f=study.fixtures()[3];mass,_=study.oracle(f);self.assertEqual(sum(mass),1)
  self.assertEqual([i for i,x in enumerate(mass) if x],[1,5])
if __name__=='__main__':unittest.main()
