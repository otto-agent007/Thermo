import unittest
from fractions import Fraction as F
from decimal import Decimal
import interval_reference as ir
class IntervalTests(unittest.TestCase):
 def test_arithmetic_encloses(self):
  for p in [4,16,32]:
   c=ir.Context(p)
   for a in [F(-1,3),F(0),F(1,7),F(9,2)]:
    for b in [F(-2,7),F(0),F(5,3)]:
     aa,bb=c.rational(a),c.rational(b)
     for got,want in [(c.add(aa,bb),a+b),(c.sub(aa,bb),a-b),(c.mul(aa,bb),a*b)]:
      self.assertLessEqual(F(got[0]),want);self.assertGreaterEqual(F(got[1]),want)
 def test_tie_and_impossible(self):
  out=ir.evaluate({'m':2,'masks':[4],'p':[[1,2]]},16)
  self.assertEqual(out['mass'][0],(Decimal('.5'),Decimal('.5')))
  self.assertEqual(out['mass'][4],(Decimal('.5'),Decimal('.5')))
  self.assertEqual(out['posterior'][0],(Decimal('.5'),Decimal('.5')))
  self.assertIsNone(out['posterior'][1])
 def test_rare_cancellation(self):
  f={'m':1,'masks':[1,2],'p':[[1,10**40],[1,3]]}
  low=ir.evaluate(f,16);high=ir.evaluate(f,128)
  self.assertIsNone(low['posterior'][1])
  self.assertLessEqual(F(high['posterior'][1][0]),F(2,3))
  self.assertGreaterEqual(F(high['posterior'][1][1]),F(2,3))
 def test_unsafe_normalization_is_unknown(self):
  c=ir.Context(16)
  self.assertIsNone(ir.posterior(c,(Decimal('-1'),Decimal('1')),(Decimal('0'),Decimal('1'))))
 def test_invalid_inputs(self):
  for f in [{'m':1,'masks':[4],'p':[[1,2]]},{'m':1,'masks':[1],'p':[[2,1]]}]:
   with self.assertRaises(ValueError):ir.evaluate(f,16)
if __name__=='__main__':unittest.main()
