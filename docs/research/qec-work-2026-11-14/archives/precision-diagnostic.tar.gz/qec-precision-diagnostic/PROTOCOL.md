# Bounded numerical-reference and synthetic screen diagnostic

Frozen before scientific outcomes, 2026-11-14. This is an authorized research
spike, not production integration or a d5 efficacy study. Prior archives unchanged.

## Question and approaches
Test outward-rounded Decimal arithmetic on the same signed Fourier identity that
underlies the d5 reference. Compare with independent primal rational enumeration.
Full rational contraction at d5 would be exact but potentially expensive; ordinary
high precision without enclosures does not certify decisions. Choose adaptive
interval precision on tiny models, with rational truth used ONLY for validation.
This full Fourier implementation is not the existing sliced tensor backend.

Inputs are independent Bernoulli fault events with binary syndrome/logical masks.
Probabilities stored as exact rational numerator/denominator pairs. Decimal-string
inputs use their rational decimal meaning; a separate fixture explicitly uses the
exact value of binary64 0.01. Not a claim of exact physical noise characterization.

## Stage A: arithmetic gate
Ten stress models: exact tie, 1e-30 near tie, rare syndrome at 1e-40,
forced p=0/1 events, dependent rows/impossible syndromes, null columns,
empty events, two rare competing explanations, exact binary64 probability,
and tiny 1e-100 cancellation. Every syndrome/class mass is checked.
At precisions 16, 32, 64, 128 decimal digits, require exact rational truth inside
EVERY raw mass interval. Posterior intervals use nonnegative mass intersections
and normalization only when syndrome-mass lower bound is positive; otherwise
unknown. Run a fixed precision sweep and report the first tested precision at which each
possible syndrome has posterior width<=1e-10 (if any); this is hypothetical
adaptive stopping, not measured adaptive runtime. Infeasible syndromes are explicitly excluded from
posterior scores. Reference winner requires an interval strictly above/below1/2;
near tie may be unresolved. No exact oracle information is used by interval code.
Any enclosure violation stops stage B. Stage A is not a proof that every future
case is enclosed; directed arithmetic correctness also requires code review.

## Stage B: fixed small out-of-sample proxy diagnostic
If Stage A passes, evaluate 12 new synthetic models, 6 development and 6 held-out,
seeds901..906 and1901..1906, 10 faults,3 syndrome bits plus1 logical bit.
Each mask is sampled uniformly1..15. Per model, probabilities repeat(.01,.08,.25)
starting at seed modulo3. All8 syndromes are evaluated, without sampled outcomes.
No fit/tuning: all methods and thresholds are frozen now.
Top1 and top4 are extracted by exhaustive enumeration, not practical search.
Their runtime is not a realistic list-decoder runtime.
Top1 and top4 exact individual-explanation masses per class form proxy margins
abs(w0-w1)/(w0+w1). Their predictions disagree only when both margins are nonzero
and signs differ. These are MLE/list SURROGATES, NOT Tesseract or BP runs.
A proxy calls a case close at margin<=.10; truth is close at P(class0|s) in[.45,.55].
Compare top1-close, top4-close, and surrogate disagreement; report confusion counts,
precision/recall where denominators exist, and prevalence. All syndromes are
uniformly counted; also report syndrome-probability-weighted counts. Synthetic
fixtures are not a random sample of physical hardware or held-out d5 conditions.
Do not tune thresholds, add models, or extrapolate an efficacy/latency advantage.

## Limits and recovery
Single-worker jobs,22 fixed models total. Each<=10CPU seconds,30wall seconds,
256MiB address space, case allowance33CPU seconds (up to3attempts). Total300CPU
seconds including runner overhead. Use existing checkpoint/lease/receipt executor,
with source/input hashes. Interrupted attempts are charged in full; ordinary nonzero-exit failures use
executor-measured CPU, retaining the receipt; no changing
model or limit on retry. Persist each completed model. Independent audit required
before final claims. No larger runs, installations, external mutations or PRs.
