import sys,json,time
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'qec-extension'))
import stim
from dem_adapter import parse_dem

def elimination(scopes,n):
 graph={i:set() for i in range(n)}
 for scope in scopes:
  for i in scope:graph[i].update(set(scope)-{i})
 order=[];sizes=[]
 while graph:
  def score(i):
   nb=graph[i];fill=sum(j not in graph[k] for k in nb for j in nb if j>k)
   return (fill,len(nb),i)
  i=min(graph,key=score);nb=graph.pop(i);order.append(i);sizes.append(len(nb))
  for j in nb:graph[j].update(nb-{j});graph[j].discard(i)
 return {'order':order,'induced_width':max(sizes,default=0),'max_multiply_entries':2**(max(sizes,default=0)+1),'sum_bucket_entries':sum(2**(s+1) for s in sizes),'degrees':sizes}

if __name__=='__main__':
 result={};start=time.perf_counter()
 for basis in ('x','z'):
  A,p=parse_dem(stim.DetectorErrorModel.from_file(f'qec-extension/inputs/{basis}-p0.005.dem'))
  result[basis]={'faults':A.shape[1],'constraints':A.shape[0], 'primal':elimination([list(np.flatnonzero(row)) for row in A],A.shape[1]),'dual':elimination([list(np.flatnonzero(col)) for col in A.T],A.shape[0])}
 result['wall_seconds']=time.perf_counter()-start
 json.dump(result,open('qec-reference/tensor-cost.json','w'),indent=2)
 print([(b,result[b]['primal']['induced_width'],result[b]['dual']['induced_width']) for b in ('x','z')])
