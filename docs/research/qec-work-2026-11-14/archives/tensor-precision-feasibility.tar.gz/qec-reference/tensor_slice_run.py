"""One bounded resource probe, not full class probability or certified reference."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
import json,time,resource,sys
from pathlib import Path
import numpy as np
from tensor_cost import elimination

def contract_slice(a,p,b,fixed,cap_bytes=3*2**30,progress=None):
 a=np.asarray(a,dtype=np.uint8);p=np.asarray(p,dtype=np.longdouble);b=np.asarray(b,dtype=np.uint8)
 m,n=a.shape
 if any(v not in (0,1) or k<0 or k>=m for k,v in fixed.items()):raise ValueError('invalid fixed binary variables')
 remaining=[i for i in range(m) if i not in fixed];mapping={v:i for i,v in enumerate(remaining)}
 scopes=[tuple(mapping[v] for v in np.flatnonzero(col) if v in mapping) for col in a.T]
 cost=elimination(scopes,len(remaining));size=3*cost['max_multiply_entries']*np.dtype(np.longdouble).itemsize
 if size>cap_bytes:raise MemoryError('planned temporary arrays exceed cap')
 scalar=np.longdouble(1)
 for i,v in fixed.items():scalar*=np.longdouble(-.5 if b[i]*v else .5)
 factors=[]
 for col,scope,prob in zip(a.T,scopes,p):
  parity=np.full((2,)*len(scope),sum(int(col[i])*v for i,v in fixed.items())%2,dtype=np.uint8)
  for axis in range(len(scope)):
   shape=[1]*len(scope);shape[axis]=2;parity^=np.arange(2,dtype=np.uint8).reshape(shape)
  factors.append((scope,1-prob+prob*(1-2*parity.astype(np.longdouble))))
 for i in remaining:factors.append(((mapping[i],),np.array([.5,-.5 if b[i] else .5],dtype=np.longdouble)))
 for step,variable in enumerate(cost['order']):
  bucket=[f for f in factors if variable in f[0]];factors=[f for f in factors if variable not in f[0]]
  union=tuple(sorted(set().union(*(set(s) for s,_ in bucket))))
  product=np.ones((2,)*len(union),dtype=np.longdouble)
  for scope,values in bucket:product*=values.reshape(tuple(2 if v in scope else 1 for v in union))
  reduced=product.sum(axis=union.index(variable));factors.append((tuple(v for v in union if v!=variable),reduced))
  if progress:progress(step+1,len(cost['order']),len(union))
 for scope,factor in factors:
  assert not scope;scalar*=factor
 return scalar

if __name__=='__main__':
 sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'qec-extension'))
 import stim
 from dem_adapter import parse_dem
 root=Path(__file__).resolve().parents[1];out=root/'qec-reference/tensor-one-slice.json'
 resource.setrlimit(resource.RLIMIT_AS,(3*2**30,3*2**30));resource.setrlimit(resource.RLIMIT_CPU,(60,60))
 start=time.perf_counter();cpu=time.process_time()
 a,p=parse_dem(stim.DetectorErrorModel.from_file(root/'qec-extension/inputs/z-p0.005.dem'))
 z=np.load(root/'qec-extension/pilot-run/z-p0.005.npz');b=np.r_[z['detectors'][7],0]
 fixed={i:0 for i in [120,21,26,39,45,46,49,50]}
 report={'status':'running','scope':'one all-zero slice of256; not class mass','cell':'z-p0.005','saved_index':7,'logical_class':0,'fixed':fixed,'cpu_cap_seconds':60,'address_space_cap_bytes':3*2**30,'dtype':str(np.dtype(np.longdouble))}
 def progress(step,total,width):
  report.update(eliminated=step,total_variables=total,last_product_rank=width,wall_seconds=time.perf_counter()-start,cpu_seconds=time.process_time()-cpu,peak_rss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
  out.write_text(json.dumps(report,indent=2))
 progress(0,113,0)
 try:
  result=contract_slice(a,p,b,fixed,progress=progress)
  report.update(status='completed',slice_value_longdouble=str(result),is_full_class_mass=False)
 except Exception as e:
  report.update(status='error',error=repr(e));raise
 finally:
  report.update(wall_seconds=time.perf_counter()-start,cpu_seconds=time.process_time()-cpu,peak_rss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
  out.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
