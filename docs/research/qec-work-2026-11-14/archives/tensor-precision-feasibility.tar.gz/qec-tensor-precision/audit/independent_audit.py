"""Bounded artifact audit, independent exact primal and dual arithmetic."""
import hashlib, itertools, json, pathlib, resource, time
from fractions import Fraction as F
from exact_oracles import primal, dual_slice
ROOT = pathlib.Path(__file__).resolve().parents[1]
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def inside(value, interval):
    lo, hi = map(F, interval)
    assert lo <= value <= hi, (value, interval)
    return hi - lo

def main():
    resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
    resource.setrlimit(resource.RLIMIT_AS, (2**30, 2**30))
    start = time.process_time()
    cfg = json.loads((ROOT/'manifest.json').read_text())
    result = json.loads((ROOT/'RESULTS.json').read_text())
    assert result['complete'] is True
    assert result['manifest_sha256'] == sha(ROOT/'manifest.json')
    for p, h in cfg['hashes'].items(): assert sha(p) == h, p
    old = json.loads((ROOT.parent/'qec-precision-diagnostic/manifest.json').read_text())
    assert cfg['fixtures'] == old['fixtures'][:10]
    assert cfg['precisions'] == [16,32,64,128]
    assert cfg['total_cpu'] == 300 and cfg['case_cpu'] == 33
    assert (cfg['cpu_limit'],cfg['wall_limit'],cfg['memory_bytes']) == (10,30,2**30)
    assert len(result['results']) == 10
    checks = {'mass':0,'slice':0,'posterior':0}
    cases = []
    for f, r in zip(cfg['fixtures'],result['results']):
        assert r['name'] == f['name'] and r['fixture'] == f
        truth = primal(f); assert sum(truth) == 1
        width = 1 << (f['m']+1)
        assert [v['fixed_variables'] for v in r['variants']] == [[],[f['m']],[0,f['m']]]
        minima = []
        for variant in r['variants']:
            fixed = variant['fixed_variables']; first = None
            assignments = list(itertools.product((0,1),repeat=len(fixed)))
            slices = [[dual_slice(f,y,dict(zip(fixed,a))) for a in assignments] for y in range(width)]
            assert all(sum(v,F(0)) == t for v,t in zip(slices,truth))
            assert [p['precision'] for p in variant['precisions']] == cfg['precisions']
            for p in variant['precisions']:
                assert len(p['mass']) == len(p['slice_terms']) == width
                assert len(p['posterior']) == width//2
                narrow = True
                for y,t in enumerate(truth):
                    inside(t,p['mass'][y]); checks['mass'] += 1
                    assert len(p['slice_terms'][y]) == len(assignments)
                    for exact,interval in zip(slices[y],p['slice_terms'][y]):
                        inside(exact,interval); checks['slice'] += 1
                for s,post in enumerate(p['posterior']):
                    den = truth[s]+truth[s+width//2]
                    if not den:
                        assert post is None
                        continue
                    if post is None:
                        narrow = False
                        continue
                    span = inside(truth[s]/den,post); checks['posterior'] += 1
                    assert 0 <= F(post[0]) <= F(post[1]) <= 1
                    narrow &= span <= F(1,10**10)
                if narrow and first is None: first = p['precision']
            assert first is not None, (f['name'],fixed)
            minima.append({'fixed_variables':fixed,'minimum_narrow_precision':first})
        cases.append({'name':f['name'],'variants':minima})
    ledger = json.loads((ROOT/'execution/ledger.json').read_text())
    assert ledger['total_limit'] == 300
    assert ledger['case_limits'] == {f['name']:33 for f in cfg['fixtures']}
    charged = sum(e['charged_cpu_seconds'] for e in ledger['entries'].values())
    assert charged <= 300
    for name in ledger['case_limits']:
        assert sum(e['charged_cpu_seconds'] for e in ledger['entries'].values() if e['case']==name) <= 33
    receipts=[]
    for folder in (ROOT/'execution/batches').iterdir():
        receipt=json.loads((folder/'receipt.json').read_text());spec=json.loads((folder/'spec.json').read_text())
        assert spec['input_hashes']=={**cfg['hashes'],str(ROOT/'manifest.json'):sha(ROOT/'manifest.json')}
        assert (spec['cpu_limit'],spec['wall_limit'],spec['memory_bytes']) == (10,30,2**30)
        assert receipt['status']=='completed' and receipt['returncode']==0
        assert receipt['output_sha256']==sha(folder/'output')
        output=json.loads((folder/'output').read_text())
        assert output==next(r for r in result['results'] if r['name']==receipt['case'])
        receipts.append(receipt)
    assert sorted(r['case'] for r in receipts)==sorted(f['name'] for f in cfg['fixtures'])
    assert not (ROOT/'execution/lease.json').exists()
    report={'pass':True,'checks':checks,'cases':cases,'charged_cpu_seconds':charged,
            'measured_receipt_cpu_seconds':sum(r['measured_cpu_seconds'] for r in receipts),
            'audit_cpu_seconds':time.process_time()-start,'audit_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            'independence':'Fraction primal enumeration plus restricted dual enumeration; imports no implementation or study code',
            'manifest_sha256':sha(ROOT/'manifest.json'),'results_sha256':sha(ROOT/'RESULTS.json')}
    (ROOT/'audit/RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__': main()
