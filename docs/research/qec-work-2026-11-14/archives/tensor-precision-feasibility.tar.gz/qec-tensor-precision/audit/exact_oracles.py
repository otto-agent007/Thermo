"""Independent exact primal enumeration and restricted dual sums.
No imports from tensor/reference/study implementation.
"""
from fractions import Fraction
from itertools import product

def primal(f):
    result = [Fraction(0) for _ in range(1 << (f['m'] + 1))]
    probabilities = [Fraction(*ratio) for ratio in f['p']]
    for faults in product((0, 1), repeat=len(probabilities)):
        weight, outcome = Fraction(1), 0
        for bit, mask, probability in zip(faults, f['masks'], probabilities):
            weight *= probability if bit else 1 - probability
            if bit:
                outcome ^= mask
        result[outcome] += weight
    return result

def dual_slice(f, outcome, fixed):
    width = f['m'] + 1
    probabilities = [Fraction(*ratio) for ratio in f['p']]
    total = Fraction(0)
    for dual in range(1 << width):
        if any(((dual >> row) & 1) != value for row, value in fixed.items()):
            continue
        term = Fraction(-1 if (dual & outcome).bit_count() % 2 else 1, 1 << width)
        for mask, probability in zip(f['masks'], probabilities):
            if (dual & mask).bit_count() % 2:
                term *= 1 - 2 * probability
        total += term
    return total

if __name__ == '__main__':
    f = {'m': 1, 'masks': [1, 2], 'p': [[1, 4], [1, 3]]}
    assert primal(f) == [Fraction(1, 2), Fraction(1, 6), Fraction(1, 4), Fraction(1, 12)]
    assert all(dual_slice(f, y, {}) == p for y, p in enumerate(primal(f)))
    assert all(sum(dual_slice(f, y, {1: v}) for v in (0, 1)) == p for y, p in enumerate(primal(f)))
    print('Exact oracle self-checks passed')
