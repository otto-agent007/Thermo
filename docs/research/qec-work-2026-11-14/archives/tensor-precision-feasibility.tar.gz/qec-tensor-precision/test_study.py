import unittest
from pathlib import Path
class RunnerTest(unittest.TestCase):
 def test_frozen_scope(self):
  import study
  self.assertEqual(len(study.fixtures()),10)
  self.assertEqual(study.variants({'m':2}),[[],[2],[0,2]])
if __name__=='__main__':unittest.main()
