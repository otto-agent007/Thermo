# Bounded actual-tensor precision feasibility
Frozen scope before outcomes: ten stress fixtures from the completed precision
spike, unchanged exact rational inputs; no development/screening models, d5 or
external actions. Test port of tensor_slice_run factor construction, min-fill
bucket elimination, sliced contraction and summation, not full Walsh transform.
Fixtures have <=3 rows and <=5 faults. Sweep 16/32/64/128 decimal digits and
fixed variable sets [], [logical row], [row0, logical row]. Check every joint
mass, slice and possible-syndrome posterior against independent rational truth.
Output remains interval, with unknown posterior when denominator cannot be
bounded positive. Success requires all enclosures correct and each possible
posterior width <=1e-10 at some precision; exact ties stay unresolved.

Scientific execution: ten sequential checkpointed worker jobs, each <=10 CPU
seconds, 30 wall seconds, 1 GiB address space; 33 CPU seconds per case (maximum
three attempts allowed, no automatic retry implemented), total 300 CPU seconds. Reuse source/input-hashed lease/receipt
executor v2. No automatic takeover of unresolved lease; interrupted attempts
charged in full. Hash-verified completed results reused, never recomputed.
Tests/audit separate bounded overhead, each invocation <=60 CPU/90 wall seconds.
Independent audit required before completion claims. No resource-limit increases
or d5 extension on success. Preserve originals and archives unchanged.

Report total measured and charged execution, memory, numerical results and
limitations. This tests arithmetic/path portability, not d5 scalability or
physical noise correctness. CT-bMPS prior art remains research only.
