"""Tiny interval port of tensor_slice_run.contract_slice's factor/bucket algorithm.
Flat table indices use least-significant axis first; no full Fourier transform.
Not a scalable implementation or blanket certification of the original backend.
"""
import itertools,sys
from pathlib import Path
from fractions import Fraction
sys.path.append(str(Path(__file__).resolve().parent.parent/'qec-precision-diagnostic'))
from interval_reference import Context,posterior

def elimination(scopes,n):
 # Same deterministic min-fill order as qec-reference/tensor_cost.py.
 graph={i:set() for i in range(n)}
 for scope in scopes:
  for i in scope:graph[i].update(set(scope)-{i})
 order=[];width=0
 while graph:
  def score(i):
   nb=graph[i];return (sum(j not in graph[k] for k in nb for j in nb if j>k),len(nb),i)
  i=min(graph,key=score);nb=graph.pop(i);order.append(i);width=max(width,len(nb))
  for j in nb:graph[j].update(nb-{j});graph[j].discard(i)
 return order,2**(width+1)

def contract_slice(a,p,b,fixed,precision,cap_entries=32):
 m=len(a);n=len(p)
 if not 0<=m<=4 or n>10 or len(b)!=m or any(len(row)!=n for row in a):raise ValueError('tiny dimensions required')
 if any(v not in (0,1) for row in a for v in row) or any(v not in (0,1) for v in b):raise ValueError('binary inputs required')
 if any(type(k) is not int or k<0 or k>=m or v not in (0,1) for k,v in fixed.items()):raise ValueError('invalid fixed variables')
 p=[Fraction(v) for v in p]
 if any(not 0<=v<=1 for v in p):raise ValueError('invalid probabilities')
 c=Context(precision);one=c.rational(1);half=c.rational(Fraction(1,2));zero=c.rational(0)
 remaining=[i for i in range(m) if i not in fixed];mapping={v:i for i,v in enumerate(remaining)}
 scopes=[tuple(mapping[v] for v in remaining if a[v][j]) for j in range(n)]
 order,size=elimination(scopes,len(remaining))
 if size>cap_entries:raise MemoryError('factor entry cap exceeded')
 scalar=one
 for i,v in fixed.items():scalar=c.mul(scalar,c.rational(-Fraction(1,2) if b[i]*v else Fraction(1,2)))
 factors=[]
 for j,(scope,prob) in enumerate(zip(scopes,p)):
  prob=c.rational(prob);offset=sum(a[i][j]*v for i,v in fixed.items())%2;values=[]
  for bits in range(2**len(scope)):
   parity=(bits.bit_count()+offset)%2
   # Preserve source factor construction 1-p+p*(1-2*parity).
   values.append(c.add(c.sub(one,prob),c.mul(prob,c.rational(1-2*parity))))
  factors.append((scope,values))
 for i in remaining:factors.append(((mapping[i],),[half,c.rational(-Fraction(1,2) if b[i] else Fraction(1,2))]))
 for variable in order:
  bucket=[f for f in factors if variable in f[0]];factors=[f for f in factors if variable not in f[0]]
  union=tuple(sorted(set().union(*(set(s) for s,_ in bucket))))
  product=[]
  for bits in range(2**len(union)):
   val=one
   for scope,values in bucket:
    idx=sum(((bits>>union.index(v))&1)<<j for j,v in enumerate(scope))
    val=c.mul(val,values[idx])
   product.append(val)
  rest=tuple(v for v in union if v!=variable);reduced=[]
  for bits in range(2**len(rest)):
   idx=sum(((bits>>j)&1)<<union.index(v) for j,v in enumerate(rest))
   reduced.append(c.add(product[idx],product[idx|(1<<union.index(variable))]))
  factors.append((rest,reduced))
 for scope,values in factors:
  assert not scope
  scalar=c.mul(scalar,values[0])
 return scalar

def evaluate(fixture,precision,fixed_variables=()):
 m=fixture['m'];masks=fixture['masks'];p=[Fraction(*v) for v in fixture['p']]
 if type(m) is not int or not 0<=m<=3 or len(masks)!=len(p) or len(p)>10:raise ValueError('tiny dimensions required')
 if any(type(v) is not int or not 0<=v<2**(m+1) for v in masks):raise ValueError('invalid masks')
 if len(set(fixed_variables))!=len(fixed_variables) or any(type(v) is not int or not 0<=v<=m for v in fixed_variables):raise ValueError('invalid sliced variables')
 a=[[(mask>>i)&1 for mask in masks] for i in range(m+1)];c=Context(precision);mass=[];all_terms=[]
 for y in range(2**(m+1)):
  b=[(y>>i)&1 for i in range(m+1)];value=c.rational(0);terms=[]
  for assignment in itertools.product((0,1),repeat=len(fixed_variables)):
   term=contract_slice(a,p,b,dict(zip(fixed_variables,assignment)),precision)
   terms.append(term);value=c.add(value,term)
  mass.append(value);all_terms.append(terms)
 return {'mass':mass,'posterior':[posterior(c,mass[s],mass[s+2**m]) for s in range(2**m)],'slice_terms':all_terms}
