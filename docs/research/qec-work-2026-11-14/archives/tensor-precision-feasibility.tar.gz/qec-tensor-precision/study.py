"""Fixed ten-fixture tensor precision diagnostic with checkpoint receipts."""
import hashlib,json,sys,time,resource
from pathlib import Path
from fractions import Fraction as F
from interval_tensor import evaluate
HOME=Path(__file__).resolve().parent
sys.path.insert(0,str(HOME.parent/'qec-targeted-study'))
from executor_v2 import atomic,initialize,run_batch,charge_overhead

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pair(x):x=F(x);return [x.numerator,x.denominator]
def fixtures():
 def f(name,m,masks,p):return dict(name=name,split='stress',m=m,masks=masks,p=[pair(x) for x in p])
 out=[f('tie',1,[2],[F(1,2)]),f('near_tie',1,[2],[F(1,2)+F(1,10**30)]),
 f('rare40',1,[1,2],[F(1,10**40),F(1,3)]),f('forced',2,[1,2,4,3],[0,1,F(1,4),1]),
 f('dependent',2,[3,7],[F(1,100),F(2,25)]),f('null',1,[0,1,2],[F(1,5),F(1,7),F(1,3)]),
 f('empty',1,[],[]),f('rare_competing',1,[1,3],[F(1,10**20),F(1,10**20)+F(1,10**50)]),
 f('binary64',2,[1,2,3,4,7],[F.from_float(.01)]*5),f('rare100',1,[1,2],[F(1,10**100),F(1,3)])]
 return out

def variants(f):return [[],[f['m']],[0,f['m']]]

def worker(config,name,output):
 start=time.process_time();cfg=json.loads(Path(config).read_text());f=next(x for x in cfg['fixtures'] if x['name']==name)
 for p,h in cfg['hashes'].items():
  if sha(p)!=h:raise ValueError('source hash changed')
 results=[]
 def serial(v):
  if isinstance(v,dict):return {k:serial(x) for k,x in v.items()}
  if isinstance(v,(list,tuple)):return [serial(x) for x in v]
  if v is None or isinstance(v,(str,int,float,bool)):return v
  return str(v)
 for fixed in variants(f):
  records=[]
  for precision in cfg['precisions']:
   result=serial(evaluate(f,precision,fixed_variables=fixed))
   records.append(dict(precision=precision,**result))
  results.append(dict(fixed_variables=fixed,precisions=records))
 atomic(output,dict(name=name,fixture=f,variants=results,cpu_seconds=time.process_time()-start,peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))

def setup():
 cfgpath=HOME/'manifest.json'
 cfg={'fixtures':fixtures(),'precisions':[16,32,64,128],'total_cpu':300,'case_cpu':33,'cpu_limit':10,'wall_limit':30,'memory_bytes':2**30,
 'hashes':{str(p.resolve()):sha(p) for p in [HOME/'PROTOCOL.md',HOME/'interval_tensor.py',HOME.parent/'qec-precision-diagnostic/interval_reference.py',HOME.parent/'qec-reference/tensor_slice_run.py',HOME.parent/'qec-reference/tensor_cost.py',Path(__file__),HOME.parent/'qec-targeted-study/executor_v2.py',Path(sys.executable).resolve()]}}
 if cfgpath.exists():
  if json.loads(cfgpath.read_text())!=cfg:raise ValueError('frozen manifest differs')
 else:atomic(cfgpath,cfg)
 if not (HOME/'execution/ledger.json').exists():initialize(HOME/'execution',300,{f['name']:33 for f in cfg['fixtures']})
 return cfgpath

def step():
 begin=time.process_time();cfgpath=setup();cfg=json.loads(cfgpath.read_text());results=[]
 for p,h in cfg['hashes'].items():
  if sha(p)!=h:raise ValueError('frozen source changed')
 for f in cfg['fixtures']:
  name=f['name'];existing=[]
  for folder in (HOME/'execution/batches').glob(name+'*') if (HOME/'execution/batches').exists() else []:
   receipt=folder/'receipt.json'
   if receipt.exists():
    r=json.loads(receipt.read_text())
    if r['case']==name and r['status']=='completed':
     spec=json.loads((folder/'spec.json').read_text())
     if spec['input_hashes']!={**cfg['hashes'],str(cfgpath):sha(cfgpath)} or spec['case']!=name:raise ValueError('saved job provenance mismatch')
     if sha(folder/'output')!=r['output_sha256']:raise ValueError('corrupt output')
     existing.append(folder/'output')
  if existing:
   if len(existing)!=1:raise ValueError('duplicate completed case')
   results.append(json.loads(existing[0].read_text()));continue
  r=run_batch(HOME/'execution',name,name,[sys.executable,str(Path(__file__).resolve()),'worker',str(cfgpath),name,'{output}'],10,30,2**30,input_hashes={**cfg['hashes'],str(cfgpath):sha(cfgpath)},caller_cpu_seconds=time.process_time())
  print(json.dumps({'case':name,'receipt':r}),flush=True);return
 ledger=json.loads((HOME/'execution/ledger.json').read_text());charge_overhead(HOME/'execution',cfg['fixtures'][-1]['name'],'final-'+str(len(ledger['entries'])),time.process_time())
 atomic(HOME/'RESULTS.json',{'manifest_sha256':sha(cfgpath),'results':results,'complete':True})
 print('COMPLETE',flush=True)
if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='worker':worker(*sys.argv[2:])
 else:step()
