import unittest,itertools
from fractions import Fraction as F
from decimal import Decimal
try:
 from interval_tensor import contract_slice,evaluate
except ImportError:
 contract_slice=evaluate=None

class TensorTests(unittest.TestCase):
 def test_slice_and_aggregate_match_independent_primal(self):
  self.assertIsNotNone(contract_slice,'tensor interval backend not implemented')
  a=[[1,1,0],[0,1,1]];p=[F(1,7),F(1,3),F(1,5)]
  truth=[F(0)]*4
  for x in itertools.product((0,1),repeat=3):
   prob=F(1)
   for bit,pp in zip(x,p):prob*=pp if bit else 1-pp
   y=[sum(v*bit for v,bit in zip(row,x))%2 for row in a]
   truth[y[0]+2*y[1]]+=prob
  fixture={'m':1,'masks':[1,3,2],'p':[[v.numerator,v.denominator] for v in p]}
  for fixed in ((),(1,),(0,1)):
   out=evaluate(fixture,32,fixed)
   for t,(lo,hi) in zip(truth,out['mass']):self.assertLessEqual(F(lo),t);self.assertLessEqual(t,F(hi))
  # Scalar factors and all fixed variables retain signed partial contributions.
  self.assertLess(contract_slice(a,p,[1,0],{0:1,1:0},32)[1],0)
 def test_unknown_rare_and_impossible(self):
  self.assertIsNotNone(evaluate,'tensor interval backend not implemented')
  f={'m':1,'masks':[1,2],'p':[[1,10**100],[1,3]]}
  self.assertIsNone(evaluate(f,16,(1,))['posterior'][1])
  out=evaluate(f,128,(1,));lo,hi=out['posterior'][1]
  self.assertLessEqual(F(lo),F(2,3));self.assertLessEqual(F(2,3),F(hi))
  f={'m':1,'masks':[],'p':[]}
  self.assertIsNone(evaluate(f,32,(1,))['posterior'][1])
 def test_guards(self):
  self.assertIsNotNone(contract_slice,'tensor interval backend not implemented')
  with self.assertRaises(ValueError):contract_slice([[1]],[F(1,2)],[0],{2:0},32)
  with self.assertRaises(MemoryError):contract_slice([[1],[1]],[F(1,2)],[0,0],{},32,cap_entries=1)
  with self.assertRaises(ValueError):evaluate({'m':4,'masks':[],'p':[]},32)

if __name__=='__main__':unittest.main()
