# Max-Cut CPU pilot bundle

Exploratory local research spike on Thermo commit 13c62e60b03282774c371459a6e6262dc77780de.

Read report.md for the protocol, every graph/method result, budget curves and limitations.
request.json hashes requested inputs and pilot.py; results.json includes per-run scores, work, timings and runtime provenance. traces.npz is a separately hashed packed trace artifact. completion.json records independent evidence replay scope.

The cloud session had a 4-CPU quota and a 16-GiB memory limit. CPU execution only. Generation took 7.193 seconds including compilation, initialization, fixture validation, baseline generation, scoring and artifact writes; replay took 1.565 seconds. Python startup and environment setup are excluded. These are evaluator timings, not device performance.

At 256 sweeps, THRML beta 1 and NumPy simulated annealing both found each graph's exact optimum in all 96 seeded runs. THRML beta 4 succeeded in 80/96 and beta 0.25 in 35/96. Greedy succeeded in 20/96 but stopped after roughly 37 spin proposals per run on average, compared with 3584 average redraws/proposals allocated to the full sampler runs. This does not show superiority over conventional annealing, scaling, or hardware speedups.

Replay from the repository root, with its existing frozen environment:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 JAX_PLATFORMS=cpu uv run --frozen python results/maxcut-cpu-pilot-2026-10-01/pilot.py --replay
```

To generate a fresh repeat, copy pilot.py unchanged to a new ignored results subdirectory and run that copy with the same environment variables. The script uses its own directory for output and refuses to overwrite results.json. Then invoke that copy with --replay. Do not edit the hashed script in a completed run directory. No scientific library, dependency lockfile, or tracked repository file was changed.

Replay regenerates exact optima, all saved cut/work metrics and baseline traces, authenticates trace/request hashes, and checks fixture probabilities. It does not rerun THRML trajectories or reproduce wall-clock timings. The initial sampler was validated against the eight-state exact triangle distribution; empirical total variation was 0.005015.
