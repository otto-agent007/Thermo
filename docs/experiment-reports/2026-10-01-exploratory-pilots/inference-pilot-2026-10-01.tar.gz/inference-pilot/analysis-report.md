# Saved THRML traces: exact-distribution and mixing check

No new samples. Retain sweeps 65..256 from each of 16 saved chains. Exact references enumerate the actual float32 model parameters in float64.

| Graph | Beta | Pooled marginal MAE | Median chain marginal MAE | Edge-correlation MAE | Cut histogram TV | Median spin ESS / 192 | Constant spin series |
|---|---:|---:|---:|---:|---:|---:|---:|
| n12-g0 | 0.25 | 0.0087 | 0.0286 | 0.0166 | 0.0468 | 158.8 | 0/192 |
| n12-g0 | 1 | 0.0061 | 0.0688 | 0.0191 | 0.0433 | 29.0 | 0/192 |
| n12-g0 | 4 | 0.2090 | 0.4974 | 0.1226 | 0.2292 | 0.0 | 152/192 |
| n12-g1 | 0.25 | 0.0072 | 0.0332 | 0.0138 | 0.0408 | 159.9 | 0/192 |
| n12-g1 | 1 | 0.0782 | 0.1128 | 0.0191 | 0.0418 | 31.6 | 0/192 |
| n12-g1 | 4 | 0.0496 | 0.4184 | 0.0598 | 0.1202 | 0.0 | 118/192 |
| n12-g2 | 0.25 | 0.0091 | 0.0284 | 0.0183 | 0.0283 | 147.6 | 0/192 |
| n12-g2 | 1 | 0.0304 | 0.0888 | 0.0119 | 0.0208 | 31.3 | 0/192 |
| n12-g2 | 4 | 0.1785 | 0.4570 | 0.0716 | 0.1445 | 0.0 | 155/192 |
| n16-g0 | 0.25 | 0.0108 | 0.0313 | 0.0174 | 0.0334 | 159.5 | 0/256 |
| n16-g0 | 1 | 0.0200 | 0.0539 | 0.0178 | 0.0327 | 55.6 | 0/256 |
| n16-g0 | 4 | 0.0327 | 0.4268 | 0.0998 | 0.2014 | 0.0 | 136/256 |
| n16-g1 | 0.25 | 0.0069 | 0.0272 | 0.0140 | 0.0457 | 161.6 | 0/256 |
| n16-g1 | 1 | 0.0135 | 0.0630 | 0.0134 | 0.0398 | 28.1 | 0/256 |
| n16-g1 | 4 | 0.1299 | 0.4932 | 0.1497 | 0.3711 | 0.0 | 188/256 |
| n16-g2 | 0.25 | 0.0084 | 0.0311 | 0.0130 | 0.0391 | 155.2 | 0/256 |
| n16-g2 | 1 | 0.1053 | 0.1768 | 0.0118 | 0.0388 | 11.2 | 0/256 |
| n16-g2 | 4 | 0.0415 | 0.5000 | 0.0155 | 0.0498 | 0.0 | 245/256 |

Marginal MAE compares the probability of a positive spin with its exact value, 0.5 by global spin-flip symmetry. Per-chain error exposes mode trapping that averaging opposite modes across seeds can hide. Low error in cut value or energy does not establish correct spin marginals.

ESS is an estimated diagnostic of these short series, not an independent sample count or convergence guarantee. Constant series have ESS 0; low cut variation can be expected at low temperature, so spin and cut diagnostics are kept separate. These post hoc summaries do not constitute a sampling release gate or full-state distribution guarantee. All per-chain diagnostics and exact references are in analysis.json.
