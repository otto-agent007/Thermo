"""Standalone figures from replay-verified research records."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

OUT = Path(__file__).resolve().parent
request = json.loads((OUT / "denoise-request.json").read_text())["request"]
results = json.loads((OUT / "denoise-results.json").read_text())
analysis = json.loads((OUT / "analysis.json").read_text())

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10})
fig, axes = plt.subplots(6, 5, figsize=(11, 12), constrained_layout=True)
titles = ["Clean image", "Noisy observation", "Exact P(white)", "THRML P(white)", "Metropolis P(white)"]
for row, case in enumerate(request["cases"]):
    cell = results["cases"][case["id"]]
    arrays = [case["clean"], case["observed"], cell["exact"]["marginals"],
              cell["methods"]["thrml"]["budgets"][-1]["pooled_pixel_probabilities"],
              cell["methods"]["metropolis"]["budgets"][-1]["pooled_pixel_probabilities"]]
    for col, values in enumerate(arrays):
        ax = axes[row, col]
        image = ax.imshow(np.asarray(values).reshape(4, 4), vmin=0, vmax=1, cmap="gray", interpolation="nearest")
        ax.set_xticks([])
        ax.set_yticks([])
        if row == 0:
            ax.set_title(titles[col])
        if col == 0:
            ax.set_ylabel(f"Seed {case['seed']}, noise {case['noise']:.0%}")
        if col == 1:
            ax.set_xlabel(f"{cell['reference']['noisy_pixel_errors']}/16 wrong")
        if col == 2:
            ax.set_xlabel(f"Posterior decision: {cell['reference']['exact_posterior_decision_errors']}/16 wrong")
fig.colorbar(image, ax=axes[:, 2:].ravel().tolist(), shrink=0.6, label="Probability that a pixel is white")
fig.suptitle("4×4 posterior denoising: exact probabilities and two samplers\nSix fixed cases; 16 chains × 1,024 sweeps per method", fontsize=14)
fig.savefig(OUT / "denoising.png", dpi=160)
fig.savefig(OUT / "denoising.pdf")
plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(11, 4.5), constrained_layout=True)
colors = {"thrml": "#2563eb", "sequential-gibbs": "#d97706", "metropolis": "#0f766e"}
for method in colors:
    for ax, metric in zip(axes, ("mean_chain_marginal_mae", "pooled_marginal_mae"), strict=True):
        errors = [np.mean([cell["methods"][method]["budgets"][i][metric] for cell in results["cases"].values()]) for i in range(3)]
        ax.plot(request["budgets"], errors, marker="o", label=method, color=colors[method])
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlabel("Sweeps per chain (16 attempted spin updates per sweep)")
        ax.set_ylabel("Pixel-probability mean absolute error")
        ax.grid(alpha=0.25)
axes[0].set_title("Mean individual-chain error")
axes[1].set_title("Error after pooling 16 independent chains")
axes[1].legend()
fig.suptitle("Exact-reference posterior accuracy; descriptive means across six cases")
fig.savefig(OUT / "posterior-accuracy.png", dpi=180)
fig.savefig(OUT / "posterior-accuracy.pdf")
plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(10, 4.5), constrained_layout=True)
betas = [0.25, 1.0, 4.0]
for ax, metric, title in zip(axes,
                           ("median_chain_marginal_mae", "median_spin_ess"),
                           ("Median per-chain marginal error", "Median estimated spin ESS / 192"), strict=True):
    values = [[row[metric] for row in analysis["rows"] if row["beta"] == beta] for beta in betas]
    for index, group in enumerate(values):
        ax.scatter(np.full(len(group), index) + np.linspace(-0.08, 0.08, len(group)), group, color="#2563eb", alpha=0.8)
        ax.plot([index - 0.2, index + 0.2], [np.median(group)] * 2, color="#111827", linewidth=2)
    ax.set_xticks(range(3), [str(beta) for beta in betas])
    ax.set_xlabel("Inverse temperature beta")
    ax.set_title(title)
    ax.grid(axis="y", alpha=0.2)
axes[0].set_ylabel("Probability error")
axes[1].set_ylabel("Estimated diagnostic; constant series = 0")
fig.suptitle("Saved Max-Cut chains: cold optimization success can hide poor mixing\nEach dot is one graph; black bar is the median across six graphs")
fig.savefig(OUT / "saved-chain-mixing.png", dpi=180)
fig.savefig(OUT / "saved-chain-mixing.pdf")
plt.close(fig)
print("Saved six standalone figures")
