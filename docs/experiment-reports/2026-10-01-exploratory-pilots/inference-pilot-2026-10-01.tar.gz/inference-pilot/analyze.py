"""Exact-distribution analysis of authenticated saved Max-Cut chains."""

import argparse
import hashlib
import json
import time
from pathlib import Path

import numpy as np

from thermo_lab.diagnostics import diagnose_series
from thermo_lab.hashing import canonical_sha256

OUT = Path(__file__).resolve().parent
SOURCE = OUT / "source"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    path = OUT / name
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    tmp.replace(path)


def states(n):
    assert n <= 16
    return ((np.arange(1 << n)[:, None] >> np.arange(n)) & 1).astype(bool)


def exact(g, beta):
    x = states(g["n"])
    spin = 2 * x.astype(np.int8) - 1
    edge_products = np.stack([spin[:, i] * spin[:, j] for i, j in g["edges"]], axis=1)
    # Enumerate the actual float32 parameters used in the prior THRML run.
    coupling = (-np.asarray(g["weights"], dtype=np.float32) / np.float32(5)).astype(np.float64)
    logp = float(np.float32(beta)) * (edge_products @ coupling)
    p = np.exp(logp - logp.max())
    p /= p.sum()
    cuts = np.sum((edge_products == -1) * np.asarray(g["weights"]), axis=1)
    marginal = p @ x
    np.testing.assert_allclose(marginal, 0.5, atol=1e-12, rtol=0)
    return {
        "marginals": marginal.tolist(),
        "pair_correlations": (p @ edge_products).tolist(),
        "mean_cut": float(p @ cuts),
        "cut_histogram": np.bincount(cuts, weights=p, minlength=sum(g["weights"]) + 1).tolist(),
    }


def source_request():
    completion = json.loads((SOURCE / "completion.json").read_text())
    request = json.loads((SOURCE / "request.json").read_text())
    assert sha(SOURCE / "results.json") == completion["results_sha256"]
    assert sha(SOURCE / "traces.npz") == completion["trace_sha256"]
    assert sha(SOURCE / "pilot.py") == request["request"]["script_sha256"]
    assert (
        canonical_sha256(request["request"])
        == request["request_digest"]
        == completion["request_digest"]
    )
    return request


def request(source):
    return {
        "schema": "maxcut_distribution_analysis.v1",
        "source_request_digest": source["request_digest"],
        "source_sha256": {
            name: sha(SOURCE / name)
            for name in (
                "pilot.py",
                "request.json",
                "results.json",
                "traces.npz",
                "completion.json",
            )
        },
        "graphs": source["request"]["graphs"],
        "betas": source["request"]["inverse_temperatures"],
        "discard_initial_states": 65,
        "retained_sweeps": "65..256 inclusive, 192 states per chain",
        "exact_reference": "float64 enumeration of actual float32 Ising couplings and beta",
        "metrics": "pooled and per-chain pixel marginals; edge correlations; cut histogram TV; cut-mean error; per-spin and cut ESS diagnostics",
        "diagnostic_limits": "short chains; ESS estimates not proof of stationarity; constant coordinates have ESS 0; chain and cut diagnostics remain separate",
        "replication": "16 independently seeded chains per graph; no pooled-sample confidence intervals",
        "no_new_sampling": True,
        "script_sha256": sha(Path(__file__)),
    }


def calculate(req):
    rows = []
    with np.load(SOURCE / "traces.npz", allow_pickle=False) as traces:
        for g in req["graphs"]:
            for beta in req["betas"]:
                name = f"{g['id']}__thrml-beta-{beta:g}"
                samples = np.unpackbits(
                    traces[name], axis=-1, count=g["n"], bitorder="little"
                ).astype(bool)[:, 65:]
                assert samples.shape == (16, 192, g["n"])
                target = exact(g, beta)
                spin = 2 * samples.astype(np.int8) - 1
                pairs = np.stack([spin[..., i] * spin[..., j] for i, j in g["edges"]], axis=-1)
                cuts = np.sum((pairs == -1) * np.asarray(g["weights"]), axis=-1)
                histogram = (
                    np.bincount(cuts.ravel(), minlength=len(target["cut_histogram"])) / cuts.size
                )
                marginal_by_chain = samples.mean(axis=1)
                mae_by_chain = np.abs(marginal_by_chain - np.asarray(target["marginals"])).mean(
                    axis=1
                )
                spin_diags = [
                    [diagnose_series(row[:, i]).model_dump(mode="json") for i in range(g["n"])]
                    for row in spin
                ]
                cut_diags = [diagnose_series(row).model_dump(mode="json") for row in cuts]
                spin_ess = [d["ess"] for row in spin_diags for d in row]
                rows.append(
                    {
                        "graph": g["id"],
                        "beta": beta,
                        "exact": target,
                        "sample_evidence": "software_simulation",
                        "reference_evidence": "exact_reference",
                        "pooled_marginal_mae": float(
                            np.abs(
                                samples.mean(axis=(0, 1)) - np.asarray(target["marginals"])
                            ).mean()
                        ),
                        "chain_marginal_mae": mae_by_chain.tolist(),
                        "median_chain_marginal_mae": float(np.median(mae_by_chain)),
                        "pooled_pair_correlation_mae": float(
                            np.abs(
                                pairs.mean(axis=(0, 1)) - np.asarray(target["pair_correlations"])
                            ).mean()
                        ),
                        "cut_histogram_tv": float(
                            np.abs(histogram - np.asarray(target["cut_histogram"])).sum() / 2
                        ),
                        "cut_mean_absolute_error": float(abs(cuts.mean() - target["mean_cut"])),
                        "median_spin_ess": float(np.median(spin_ess)),
                        "constant_spin_series": sum(
                            d["status"] == "constant_series" for row in spin_diags for d in row
                        ),
                        "spin_series": 16 * g["n"],
                        "median_cut_ess": float(np.median([d["ess"] for d in cut_diags])),
                        "spin_diagnostics": spin_diags,
                        "cut_diagnostics": cut_diags,
                    }
                )
    return rows


def report(result):
    lines = [
        "# Saved THRML traces: exact-distribution and mixing check",
        "",
        "No new samples. Retain sweeps 65..256 from each of 16 saved chains. Exact references enumerate the actual float32 model parameters in float64.",
        "",
        "| Graph | Beta | Pooled marginal MAE | Median chain marginal MAE | Edge-correlation MAE | Cut histogram TV | Median spin ESS / 192 | Constant spin series |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in result["rows"]:
        lines.append(
            f"| {r['graph']} | {r['beta']:g} | {r['pooled_marginal_mae']:.4f} | {r['median_chain_marginal_mae']:.4f} | {r['pooled_pair_correlation_mae']:.4f} | {r['cut_histogram_tv']:.4f} | {r['median_spin_ess']:.1f} | {r['constant_spin_series']}/{r['spin_series']} |"
        )
    lines += [
        "",
        "Marginal MAE compares the probability of a positive spin with its exact value, 0.5 by global spin-flip symmetry. Per-chain error exposes mode trapping that averaging opposite modes across seeds can hide. Low error in cut value or energy does not establish correct spin marginals.",
        "",
        "ESS is an estimated diagnostic of these short series, not an independent sample count or convergence guarantee. Constant series have ESS 0; low cut variation can be expected at low temperature, so spin and cut diagnostics are kept separate. These post hoc summaries do not constitute a sampling release gate or full-state distribution guarantee. All per-chain diagnostics and exact references are in analysis.json.",
    ]
    return "\n".join(lines) + "\n"


def main(replay=False):
    started = time.perf_counter()
    req = request(source_request())
    rows = calculate(req)
    result = {"request": req, "request_digest": canonical_sha256(req), "rows": rows}
    if replay:
        stored = json.loads((OUT / "analysis.json").read_text())
        assert stored == result
        assert (OUT / "analysis-report.md").read_text() == report(stored)
        write(
            "analysis-completion.json",
            {
                "status": "exploratory_analysis_complete",
                "replayed": True,
                "rows": len(rows),
                "analysis_sha256": sha(OUT / "analysis.json"),
                "request_digest": result["request_digest"],
                "replay_seconds": time.perf_counter() - started,
            },
        )
        print("Analysis replay passed", flush=True)
    else:
        if (OUT / "analysis.json").exists():
            raise FileExistsError("analysis already exists; use --replay")
        write("analysis.json", result)
        (OUT / "analysis-report.md").write_text(report(result))
        for beta in req["betas"]:
            group = [r for r in rows if r["beta"] == beta]
            print(
                "beta",
                beta,
                "median chain marginal MAE",
                round(float(np.median([r["median_chain_marginal_mae"] for r in group])), 4),
                "median spin ESS",
                round(float(np.median([r["median_spin_ess"] for r in group])), 2),
                "constant coordinates",
                sum(r["constant_spin_series"] for r in group),
                "/",
                sum(r["spin_series"] for r in group),
                flush=True,
            )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", action="store_true")
    main(parser.parse_args().replay)
