"""Exploratory CPU Max-Cut pilot; local research script, not a production backend."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import itertools
import json
import platform
import subprocess
import time
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import thrml
from thrml import Block, SamplingSchedule, SpinNode, sample_states
from thrml.models import IsingEBM, IsingSamplingProgram

from thermo_lab.hashing import canonical_sha256

OUT = Path(__file__).resolve().parent
BUDGETS = [1, 4, 16, 64, 256]
RUNS = 16
BETAS = [0.25, 1.0, 4.0]
HORIZON = 256


def write(name, value):
    path = OUT / name
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def graph(n, seed):
    rng = np.random.default_rng(seed)
    ring = {tuple(sorted((i, (i + 1) % n))) for i in range(n)}
    for _ in range(10_000):
        order = rng.permutation(n)
        matching = {tuple(sorted(map(int, order[i : i + 2]))) for i in range(0, n, 2)}
        if not ring & matching:
            break
    else:
        raise RuntimeError("matching generation failed")
    edges = sorted(ring | matching)
    weights = rng.integers(1, 6, len(edges)).tolist()
    return {"id": f"n{n}-g{seed}", "n": n, "seed": seed, "edges": edges, "weights": weights}


def request():
    return {
        "schema": "maxcut_cpu_pilot.v1",
        "status": "exploratory",
        "graph_family": "Hamiltonian ring plus nonadjacent random perfect matching; degree 3",
        "graphs": [graph(n, seed) for n in (12, 16) for seed in (0, 1, 2)],
        "graph_weight_distribution": "integer uniform 1..5",
        "run_seeds": list(range(RUNS)),
        "budgets_sweeps": BUDGETS,
        "horizon_sweeps": HORIZON,
        "inverse_temperatures": BETAS,
        "dtype": "float32 sampler; integer cut scores; float64 exact fixture probabilities",
        "ising_mapping": "zero fields; J_ij=-w_ij/5; P(s) proportional to exp(2*beta*cut(s)/5)",
        "sample_definition": "one observed chain state after a complete color-block Gibbs sweep; correlated",
        "initial_observation": "THRML n_samples=257 includes initial state and 256 updates",
        "initialization": "JAX uniform spins; root fold_in(graph_index, run_seed), split init/sample; same initial state for all methods",
        "gibbs_schedule": "greedy vertex-order graph coloring, blocks in color order; zero warmup",
        "baselines": {
            "greedy": "random-permutation strictly improving single-spin flips; stop after first no-flip sweep",
            "anneal": "random-permutation single-spin Metropolis; beta linear 0.1..4 across 256 sweeps",
        },
        "quality": "best observed cut including initial state and sweep endpoints; per-run optimum hits and gap",
        "work": "Gibbs spin redraws or baseline spin proposals, separately labeled; per-run and budget",
        "timing": "16-run batch; compilation and one untimed synchronized launch separated; median of three synchronized launches; output transfer, scoring and initialization excluded",
        "baseline_timing": "16 NumPy/Python runs including state copying, per-proposal gain computations and trajectory recording; excludes initialization and post-run scoring",
        "fixture": {
            "graph": {
                "id": "triangle",
                "n": 3,
                "edges": [(0, 1), (0, 2), (1, 2)],
                "weights": [1, 2, 3],
            },
            "beta": 0.7,
            "chains": 4,
            "sweeps": 8192,
            "discard_states": 129,
            "empirical_tv_tolerance": 0.03,
        },
        "inference": "descriptive pilot, no confidence interval treating correlated states as replicates; limited graph family",
        "evidence": {
            "enumeration": "exact_reference",
            "samplers_and_heuristics": "software_simulation",
            "timings": "observed CPU evaluator timings",
        },
        "trace_artifact": "separately SHA-256 hashed packed state traces and cumulative work arrays in traces.npz",
        "script_sha256": sha(Path(__file__)),
    }


def cut(states, g):
    states = np.asarray(states, dtype=bool)
    result = np.zeros(states.shape[:-1], dtype=np.int64)
    for (i, j), w in zip(g["edges"], g["weights"], strict=True):
        result += int(w) * (states[..., i] != states[..., j])
    return result


def all_states(n):
    if n > 16:
        raise ValueError("exact enumeration bounded at 16 nodes")
    return ((np.arange(1 << n)[:, None] >> np.arange(n)) & 1).astype(bool)


def exact(g):
    start = time.perf_counter()
    states = all_states(g["n"])
    values = cut(states, g)
    best = int(values.max())
    witness = states[int(values.argmax())].astype(int).tolist()
    assert (
        sum(
            w
            for (i, j), w in zip(g["edges"], g["weights"], strict=True)
            if witness[i] != witness[j]
        )
        == best
    )
    return {
        "evidence_class": "exact_reference",
        "optimum": best,
        "witness": witness,
        "optimal_states": int((values == best).sum()),
        "enumerated_states": len(states),
        "enumeration_seconds": time.perf_counter() - start,
    }


def blocks(g):
    colors = []
    neighbors = [set() for _ in range(g["n"])]
    for i, j in g["edges"]:
        neighbors[i].add(j)
        neighbors[j].add(i)
    for i in range(g["n"]):
        used = {colors[j] for j in neighbors[i] if j < i}
        colors.append(next(c for c in range(g["n"]) if c not in used))
    assert all(colors[i] != colors[j] for i, j in g["edges"])
    return [
        np.array([i for i, c in enumerate(colors) if c == color])
        for color in range(max(colors) + 1)
    ]


def compile_sampler(g, horizon, keys, initial):
    nodes = [SpinNode() for _ in range(g["n"])]
    edges = [(nodes[i], nodes[j]) for i, j in g["edges"]]
    partition = blocks(g)
    free = [Block([nodes[int(i)] for i in color]) for color in partition]
    schedule = SamplingSchedule(0, horizon + 1, 1)

    def chain(key, initial_state, beta):
        model = IsingEBM(
            nodes,
            edges,
            jnp.zeros(g["n"], dtype=jnp.float32),
            -jnp.asarray(g["weights"], dtype=jnp.float32) / 5,
            beta,
        )
        program = IsingSamplingProgram(model, free, [])
        return sample_states(
            key,
            program,
            schedule,
            [initial_state[color] for color in partition],
            [],
            [Block(nodes)],
        )[0]

    fn = jax.jit(jax.vmap(chain, in_axes=(0, 0, None)))
    started = time.perf_counter()
    executable = fn.lower(keys, initial, jnp.float32(BETAS[0])).compile()
    return executable, time.perf_counter() - started, [c.tolist() for c in partition]


def initial_states(index, runs=RUNS):
    roots = [
        jax.random.fold_in(jax.random.fold_in(jax.random.key(20261001), index), r)
        for r in range(runs)
    ]
    pairs = [jax.random.split(root) for root in roots]
    return pairs


def fixture_check(spec):
    g = spec["graph"]
    states = all_states(3)
    values = cut(states, g)
    independent = np.array(
        [
            sum(w for (i, j), w in zip(g["edges"], g["weights"], strict=True) if row[i] != row[j])
            for row in itertools.product((False, True), repeat=3)
        ]
    )
    assert sorted(values.tolist()) == sorted(independent.tolist())
    assert int(values.max()) == 5
    logp = 2 * spec["beta"] * values / 5
    p = np.exp(logp - logp.max())
    p /= p.sum()
    pairs = initial_states(99, spec["chains"])
    initial = jnp.stack([jax.random.bernoulli(a, shape=(3,)) for a, _ in pairs])
    keys = jnp.stack([b for _, b in pairs])
    exe, compile_s, _ = compile_sampler(g, spec["sweeps"], keys, initial)
    traces = np.asarray(exe(keys, initial, jnp.float32(spec["beta"])).block_until_ready())
    assert np.array_equal(traces[:, 0], np.asarray(initial))
    codes = (traces[:, spec["discard_states"] :] * (1 << np.arange(3))).sum(axis=-1)
    observed = np.bincount(codes.ravel(), minlength=8) / codes.size
    tv = float(np.abs(observed - p).sum() / 2)
    assert tv < spec["empirical_tv_tolerance"], (tv, observed, p)
    # Complement symmetry, bipartite known optimum, and flip-gain sign.
    assert np.array_equal(cut(~states, g), values)
    path = {"n": 4, "edges": [(0, 1), (1, 2), (2, 3)], "weights": [1, 2, 3]}
    assert int(cut(all_states(4), path).max()) == 6
    for row in states:
        for i in range(3):
            spin = 2 * row.astype(int) - 1
            gain = sum(
                w * spin[i] * spin[j if i == a else a]
                for (a, j), w in zip(g["edges"], g["weights"], strict=True)
                if i in (a, j)
            )
            flipped = row.copy()
            flipped[i] = ~flipped[i]
            assert int(cut(flipped, g) - cut(row, g)) == gain
    return {
        "passed": True,
        "exact_optimum": 5,
        "empirical_tv": tv,
        "exact_probabilities": p.tolist(),
        "empirical_probabilities": observed.tolist(),
        "chains": spec["chains"],
        "correlated_observations": int(codes.size),
        "compile_seconds": compile_s,
    }, traces


def baseline(g, initial, index, method):
    neighbors = [[] for _ in range(g["n"])]
    for (i, j), w in zip(g["edges"], g["weights"], strict=True):
        neighbors[i].append((j, w))
        neighbors[j].append((i, w))
    traces = np.empty((RUNS, HORIZON + 1, g["n"]), dtype=bool)
    work = np.zeros((RUNS, HORIZON + 1), dtype=np.int64)
    start = time.perf_counter()
    for run in range(RUNS):
        rng = np.random.default_rng(
            np.random.SeedSequence([20261001, index, run, 7 if method == "greedy" else 8])
        )
        spin = 2 * initial[run].astype(np.int64) - 1
        traces[run, 0] = spin > 0
        stopped = False
        for sweep in range(1, HORIZON + 1):
            proposals = 0
            flips = 0
            if not stopped:
                beta = 0.1 + 3.9 * (sweep - 1) / (HORIZON - 1)
                for i in rng.permutation(g["n"]):
                    gain = sum(w * spin[i] * spin[j] for j, w in neighbors[i])
                    proposals += 1
                    accept = (
                        gain > 0
                        if method == "greedy"
                        else (gain >= 0 or rng.random() < np.exp(2 * beta * gain / 5))
                    )
                    if accept:
                        spin[i] *= -1
                        flips += 1
                if method == "greedy" and flips == 0:
                    stopped = True
            traces[run, sweep] = spin > 0
            work[run, sweep] = work[run, sweep - 1] + proposals
    return traces, work, time.perf_counter() - start


def metrics(g, traces, work, optimum):
    values = cut(traces, g)
    assert traces.shape == (RUNS, HORIZON + 1, g["n"])
    assert values.max() <= optimum
    best = np.maximum.accumulate(values, axis=1)
    return [
        {
            "sweeps": b,
            "best_cut_by_run": best[:, b].tolist(),
            "gap_by_run": (optimum - best[:, b]).tolist(),
            "optimum_hits": int((best[:, b] == optimum).sum()),
            "mean_relative_gap": float(((optimum - best[:, b]) / optimum).mean()),
            "mean_best_cut": float(best[:, b].mean()),
            "work_by_run": work[:, b].tolist(),
        }
        for b in BUDGETS
    ]


def report(req, results):
    lines = [
        "# Exploratory sparse Max-Cut CPU pilot",
        "",
        "Local research spike; not a production backend or a release study.",
        "",
        "Six degree-3 graphs (12/16 vertices, three graph seeds each), integer edge weights 1..5; 16 independent run seeds per method and graph. Exact optima by complete enumeration.",
        "",
        "THRML uses float32 color-block Gibbs, beta 0.25/1/4, no burn-in, initial state plus 256 sweeps. Best cut uses initial and sweep-end states. NumPy annealing ramps beta 0.1..4 over the full 256-sweep horizon; short-budget rows are prefixes of that fixed schedule. Greedy stops at a strict single-spin local optimum.",
        "",
        "## Quality at 256 sweeps",
        "",
        "| Graph | Exact optimum | Method | Optimum hits / 16 | Mean relative gap | CPU batch seconds |",
        "|---|---:|---|---:|---:|---:|",
    ]
    methods = [f"thrml-beta-{b:g}" for b in BETAS] + ["greedy", "anneal"]
    for g in req["graphs"]:
        r = results["graphs"][g["id"]]
        for name in methods:
            arm = r["methods"][name]
            m = arm["budgets"][-1]
            lines.append(
                f"| {g['id']} | {r['exact']['optimum']} | {name} | {m['optimum_hits']}/16 | {m['mean_relative_gap']:.5f} | {arm['batch_execution_seconds']:.6f} |"
            )
    lines += [
        "",
        "## Descriptive budget summary",
        "",
        "Aggregate over the six fixed graphs and 96 seeded runs per method. These are descriptive counts, not population confidence intervals.",
        "",
        "| Method | Sweeps | Optimum hits / 96 | Mean relative gap | Mean redraws or proposals per run |",
        "|---|---:|---:|---:|---:|",
    ]
    for name in methods:
        for i, budget in enumerate(BUDGETS):
            ms = [results["graphs"][g["id"]]["methods"][name]["budgets"][i] for g in req["graphs"]]
            lines.append(
                f"| {name} | {budget} | {sum(m['optimum_hits'] for m in ms)}/96 | {np.mean([m['mean_relative_gap'] for m in ms]):.5f} | {np.mean([w for m in ms for w in m['work_by_run']]):.1f} |"
            )
    lines += [
        "",
        "## Timing and interpretation",
        "",
        "Each THRML batch contains 16 chains. Reported seconds are the median of three synchronized CPU launches after one untimed launch; compilation is recorded separately once per graph and shared across beta values. Transfers, initialization and cut scoring are excluded. Baseline seconds cover Python/NumPy trajectory generation, including recording and gain evaluation, for the same 16 starting states. Implementations and timed scopes differ: this is not an equal-cost speed or hardware comparison.",
        "",
        "Gibbs work counts vertex redraws; baselines count single-spin proposals. The budgets bound attempted vertex updates, not equal compute, energy or device operations. Greedy's actual work stops early. Repeated chain states are correlated and are never treated as independent samples.",
        "",
        "Three beta choices are all shown; selecting the best after seeing these graphs is exploratory. Six small graphs from one restricted family do not establish scaling or general superiority. All sampler/heuristic outcomes are software_simulation; optima are exact_reference. No TSU/Z1 hardware claim.",
        "",
        "Full per-run scores, gaps, work, exact witnesses, compile timings and runtime provenance are in results.json. Separately hashed packed traces in traces.npz support metric replay. request.json pins the requested inputs and pilot script. completion.json is written only by a separate replay command.",
    ]
    return "\n".join(lines) + "\n"


def run():
    if (OUT / "results.json").exists():
        raise FileExistsError("existing pilot results; use --replay, do not overwrite")
    if thrml.__version__ != "0.1.4" or jax.default_backend() != "cpu":
        raise RuntimeError("requires pinned THRML 0.1.4 on CPU")
    started = time.perf_counter()
    req = request()
    write("request.json", {"request": req, "request_digest": canonical_sha256(req)})
    fixture, fixture_trace = fixture_check(req["fixture"])
    print(f"Fixture passed: TV={fixture['empirical_tv']:.6f}", flush=True)
    result = {
        "request_digest": canonical_sha256(req),
        "fixture": fixture,
        "graphs": {},
        "runtime": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "packages": {
                n: importlib.metadata.version(n)
                for n in ("jax", "jaxlib", "thrml", "numpy", "scipy")
            },
            "jax_backend": jax.default_backend(),
            "jax_devices": [str(d) for d in jax.devices()],
            "jax_enable_x64": bool(jax.config.jax_enable_x64),
            "git_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
            "git_dirty": bool(
                subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
            ),
            "cpu_quota": Path("/sys/fs/cgroup/cpu.max").read_text().strip()
            if Path("/sys/fs/cgroup/cpu.max").exists()
            else None,
            "memory_limit_bytes": Path("/sys/fs/cgroup/memory.max").read_text().strip()
            if Path("/sys/fs/cgroup/memory.max").exists()
            else None,
        },
    }
    traces = {"fixture": np.packbits(fixture_trace, axis=-1, bitorder="little")}
    for index, g in enumerate(req["graphs"]):
        pairs = initial_states(index)
        initial = jnp.stack(
            [jax.random.bernoulli(a, shape=(g["n"],)) for a, _ in pairs]
        ).block_until_ready()
        keys = jnp.stack([b for _, b in pairs])
        initial_np = np.asarray(initial)
        exact_result = exact(g)
        exe, compilation, partition = compile_sampler(g, HORIZON, keys, initial)
        cell = {
            "exact": exact_result,
            "gibbs_blocks": partition,
            "compile_seconds_shared": compilation,
            "methods": {},
        }
        for beta in BETAS:
            name = f"thrml-beta-{beta:g}"
            exe(keys, initial, jnp.float32(beta)).block_until_ready()
            times = []
            for _ in range(3):
                t = time.perf_counter()
                observed = exe(keys, initial, jnp.float32(beta)).block_until_ready()
                times.append(time.perf_counter() - t)
            states = np.asarray(observed)
            assert np.array_equal(states[:, 0], initial_np)
            work = np.broadcast_to(np.arange(HORIZON + 1) * g["n"], (RUNS, HORIZON + 1)).copy()
            cell["methods"][name] = {
                "evidence_class": "software_simulation",
                "work_unit": "spin_redraws",
                "batch_execution_seconds": float(np.median(times)),
                "launch_seconds": times,
                "budgets": metrics(g, states, work, exact_result["optimum"]),
            }
            traces[f"{g['id']}__{name}"] = np.packbits(states, axis=-1, bitorder="little")
            traces[f"{g['id']}__{name}__work"] = work
        for name in ("greedy", "anneal"):
            states, work, elapsed = baseline(g, initial_np, index, name)
            cell["methods"][name] = {
                "evidence_class": "software_simulation",
                "work_unit": "spin_proposals",
                "batch_execution_seconds": elapsed,
                "budgets": metrics(g, states, work, exact_result["optimum"]),
            }
            traces[f"{g['id']}__{name}"] = np.packbits(states, axis=-1, bitorder="little")
            traces[f"{g['id']}__{name}__work"] = work
        result["graphs"][g["id"]] = cell
        write("results.partial.json", result)
        print(
            g["id"],
            "optimum",
            exact_result["optimum"],
            "hits",
            {k: v["budgets"][-1]["optimum_hits"] for k, v in cell["methods"].items()},
            flush=True,
        )
    np.savez_compressed(OUT / "traces.npz", **traces)
    result["trace_sha256"] = sha(OUT / "traces.npz")
    result["total_run_seconds"] = time.perf_counter() - started
    write("results.json", result)
    (OUT / "report.md").write_text(report(req, result))
    print(f"Generation finished in {result['total_run_seconds']:.2f}s; replay required", flush=True)


def replay():
    start = time.perf_counter()
    frozen = json.loads((OUT / "request.json").read_text())
    req = frozen["request"]
    assert req == json.loads(json.dumps(request()))
    assert frozen["request_digest"] == canonical_sha256(req)
    result = json.loads((OUT / "results.json").read_text())
    assert result["request_digest"] == frozen["request_digest"]
    assert result["trace_sha256"] == sha(OUT / "traces.npz")
    with np.load(OUT / "traces.npz", allow_pickle=False) as trace:
        f = np.unpackbits(trace["fixture"], axis=-1, count=3, bitorder="little").astype(bool)
        codes = (f[:, req["fixture"]["discard_states"] :] * (1 << np.arange(3))).sum(axis=-1)
        empirical = np.bincount(codes.ravel(), minlength=8) / codes.size
        np.testing.assert_array_equal(empirical, result["fixture"]["empirical_probabilities"])
        vals = cut(all_states(3), req["fixture"]["graph"])
        p = np.exp(2 * req["fixture"]["beta"] * (vals - vals.max()) / 5)
        p /= p.sum()
        tv = float(np.abs(empirical - p).sum() / 2)
        assert tv < req["fixture"]["empirical_tv_tolerance"]
        for index, g in enumerate(req["graphs"]):
            cell = result["graphs"][g["id"]]
            recomputed = exact(g)
            assert {k: v for k, v in recomputed.items() if k != "enumeration_seconds"} == {
                k: v for k, v in cell["exact"].items() if k != "enumeration_seconds"
            }
            pairs = initial_states(index)
            init = np.stack(
                [np.asarray(jax.random.bernoulli(a, shape=(g["n"],))) for a, _ in pairs]
            )
            for name, arm in cell["methods"].items():
                states = np.unpackbits(
                    trace[f"{g['id']}__{name}"], axis=-1, count=g["n"], bitorder="little"
                ).astype(bool)
                work = trace[f"{g['id']}__{name}__work"]
                np.testing.assert_array_equal(states[:, 0], init)
                assert metrics(g, states, work, recomputed["optimum"]) == arm["budgets"]
                if name.startswith("thrml"):
                    np.testing.assert_array_equal(
                        work, np.broadcast_to(np.arange(HORIZON + 1) * g["n"], work.shape)
                    )
                else:
                    regenerated, expected_work, _ = baseline(g, init, index, name)
                    np.testing.assert_array_equal(states, regenerated)
                    np.testing.assert_array_equal(work, expected_work)
    assert (OUT / "report.md").read_text() == report(req, result)
    write(
        "completion.json",
        {
            "status": "exploratory_pilot_complete",
            "replayed": True,
            "graphs": len(req["graphs"]),
            "arms": 5,
            "runs_per_graph_arm": RUNS,
            "request_digest": canonical_sha256(req),
            "results_sha256": sha(OUT / "results.json"),
            "trace_sha256": sha(OUT / "traces.npz"),
            "replay_seconds": time.perf_counter() - start,
            "scope": "exact optima, every stored quality/work metric, initial states, fixture probabilities and baseline traces; THRML trace trajectories not regenerated",
        },
    )
    print(
        "Replay passed: exact optima, all 30 arms, all metrics and baseline trajectories",
        flush=True,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    try:
        replay() if args.replay else run()
    except Exception as exc:
        write("failure.json", {"type": type(exc).__name__, "message": str(exc)})
        raise
