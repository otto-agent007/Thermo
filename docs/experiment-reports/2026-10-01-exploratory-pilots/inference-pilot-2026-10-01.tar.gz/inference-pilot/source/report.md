# Exploratory sparse Max-Cut CPU pilot

Local research spike; not a production backend or a release study.

Six degree-3 graphs (12/16 vertices, three graph seeds each), integer edge weights 1..5; 16 independent run seeds per method and graph. Exact optima by complete enumeration.

THRML uses float32 color-block Gibbs, beta 0.25/1/4, no burn-in, initial state plus 256 sweeps. Best cut uses initial and sweep-end states. NumPy annealing ramps beta 0.1..4 over the full 256-sweep horizon; short-budget rows are prefixes of that fixed schedule. Greedy stops at a strict single-spin local optimum.

## Quality at 256 sweeps

| Graph | Exact optimum | Method | Optimum hits / 16 | Mean relative gap | CPU batch seconds |
|---|---:|---|---:|---:|---:|
| n12-g0 | 48 | thrml-beta-0.25 | 14/16 | 0.00651 | 0.009106 |
| n12-g0 | 48 | thrml-beta-1 | 16/16 | 0.00000 | 0.008997 |
| n12-g0 | 48 | thrml-beta-4 | 14/16 | 0.00521 | 0.008774 |
| n12-g0 | 48 | greedy | 2/16 | 0.05078 | 0.008961 |
| n12-g0 | 48 | anneal | 16/16 | 0.00000 | 0.152743 |
| n12-g1 | 49 | thrml-beta-0.25 | 7/16 | 0.01786 | 0.005637 |
| n12-g1 | 49 | thrml-beta-1 | 16/16 | 0.00000 | 0.007075 |
| n12-g1 | 49 | thrml-beta-4 | 16/16 | 0.00000 | 0.005920 |
| n12-g1 | 49 | greedy | 9/16 | 0.02679 | 0.005880 |
| n12-g1 | 49 | anneal | 16/16 | 0.00000 | 0.150582 |
| n12-g2 | 53 | thrml-beta-0.25 | 8/16 | 0.01297 | 0.007086 |
| n12-g2 | 53 | thrml-beta-1 | 16/16 | 0.00000 | 0.007577 |
| n12-g2 | 53 | thrml-beta-4 | 13/16 | 0.00354 | 0.007229 |
| n12-g2 | 53 | greedy | 3/16 | 0.07783 | 0.005302 |
| n12-g2 | 53 | anneal | 16/16 | 0.00000 | 0.149169 |
| n16-g0 | 54 | thrml-beta-0.25 | 2/16 | 0.04630 | 0.009998 |
| n16-g0 | 54 | thrml-beta-1 | 16/16 | 0.00000 | 0.010432 |
| n16-g0 | 54 | thrml-beta-4 | 10/16 | 0.00926 | 0.010085 |
| n16-g0 | 54 | greedy | 1/16 | 0.08565 | 0.005636 |
| n16-g0 | 54 | anneal | 16/16 | 0.00000 | 0.198614 |
| n16-g1 | 64 | thrml-beta-0.25 | 1/16 | 0.07031 | 0.008542 |
| n16-g1 | 64 | thrml-beta-1 | 16/16 | 0.00000 | 0.007549 |
| n16-g1 | 64 | thrml-beta-4 | 11/16 | 0.02539 | 0.008780 |
| n16-g1 | 64 | greedy | 1/16 | 0.11914 | 0.005913 |
| n16-g1 | 64 | anneal | 16/16 | 0.00000 | 0.194640 |
| n16-g2 | 77 | thrml-beta-0.25 | 3/16 | 0.08685 | 0.005239 |
| n16-g2 | 77 | thrml-beta-1 | 16/16 | 0.00000 | 0.004946 |
| n16-g2 | 77 | thrml-beta-4 | 16/16 | 0.00000 | 0.005193 |
| n16-g2 | 77 | greedy | 4/16 | 0.13149 | 0.005716 |
| n16-g2 | 77 | anneal | 16/16 | 0.00000 | 0.200728 |

## Descriptive budget summary

Aggregate over the six fixed graphs and 96 seeded runs per method. These are descriptive counts, not population confidence intervals.

| Method | Sweeps | Optimum hits / 96 | Mean relative gap | Mean redraws or proposals per run |
|---|---:|---:|---:|---:|
| thrml-beta-0.25 | 1 | 1/96 | 0.34041 | 14.0 |
| thrml-beta-0.25 | 4 | 1/96 | 0.23054 | 56.0 |
| thrml-beta-0.25 | 16 | 3/96 | 0.15152 | 224.0 |
| thrml-beta-0.25 | 64 | 13/96 | 0.08528 | 896.0 |
| thrml-beta-0.25 | 256 | 35/96 | 0.04013 | 3584.0 |
| thrml-beta-1 | 1 | 5/96 | 0.20389 | 14.0 |
| thrml-beta-1 | 4 | 23/96 | 0.08660 | 56.0 |
| thrml-beta-1 | 16 | 61/96 | 0.01753 | 224.0 |
| thrml-beta-1 | 64 | 87/96 | 0.00251 | 896.0 |
| thrml-beta-1 | 256 | 96/96 | 0.00000 | 3584.0 |
| thrml-beta-4 | 1 | 10/96 | 0.11461 | 14.0 |
| thrml-beta-4 | 4 | 29/96 | 0.05535 | 56.0 |
| thrml-beta-4 | 16 | 46/96 | 0.02954 | 224.0 |
| thrml-beta-4 | 64 | 59/96 | 0.01758 | 896.0 |
| thrml-beta-4 | 256 | 80/96 | 0.00723 | 3584.0 |
| greedy | 1 | 9/96 | 0.12627 | 14.0 |
| greedy | 4 | 19/96 | 0.08276 | 36.6 |
| greedy | 16 | 20/96 | 0.08195 | 37.1 |
| greedy | 64 | 20/96 | 0.08195 | 37.1 |
| greedy | 256 | 20/96 | 0.08195 | 37.1 |
| anneal | 1 | 0/96 | 0.42062 | 14.0 |
| anneal | 4 | 0/96 | 0.32939 | 56.0 |
| anneal | 16 | 3/96 | 0.16201 | 224.0 |
| anneal | 64 | 70/96 | 0.00986 | 896.0 |
| anneal | 256 | 96/96 | 0.00000 | 3584.0 |

## Timing and interpretation

Each THRML batch contains 16 chains. Reported seconds are the median of three synchronized CPU launches after one untimed launch; compilation is recorded separately once per graph and shared across beta values. Transfers, initialization and cut scoring are excluded. Baseline seconds cover Python/NumPy trajectory generation, including recording and gain evaluation, for the same 16 starting states. Implementations and timed scopes differ: this is not an equal-cost speed or hardware comparison.

Gibbs work counts vertex redraws; baselines count single-spin proposals. The budgets bound attempted vertex updates, not equal compute, energy or device operations. Greedy's actual work stops early. Repeated chain states are correlated and are never treated as independent samples.

Three beta choices are all shown; selecting the best after seeing these graphs is exploratory. Six small graphs from one restricted family do not establish scaling or general superiority. All sampler/heuristic outcomes are software_simulation; optima are exact_reference. No TSU/Z1 hardware claim.

Full per-run scores, gaps, work, exact witnesses, compile timings and runtime provenance are in results.json. Separately hashed packed traces in traces.npz support metric replay. request.json pins the requested inputs and pilot script. completion.json is written only by a separate replay command.
