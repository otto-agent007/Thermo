"""Small posterior-denoising research spike with exact Ising references."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import platform
import subprocess
import time
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
from thrml import Block, SamplingSchedule, SpinNode, sample_states
from thrml.models import IsingEBM, IsingSamplingProgram

from thermo_lab.diagnostics import diagnose_series
from thermo_lab.hashing import canonical_sha256

OUT = Path(__file__).resolve().parent
N = 16
RUNS = 16
HORIZON = 1024
BUDGETS = [64, 256, 1024]
DISCARD = 33
COUPLING = float(np.float32(0.4))
EDGES = [
    (i, j)
    for i in range(N)
    for j in range(i + 1, N)
    if abs(i // 4 - j // 4) + abs(i % 4 - j % 4) == 1
]
METHODS = ["thrml", "sequential-gibbs", "metropolis"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    path = OUT / name
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temp.replace(path)


def all_states(n):
    assert n <= 16
    return ((np.arange(1 << n)[:, None] >> np.arange(n)) & 1).astype(bool)


def exact(fields, coupling, edges):
    x = all_states(len(fields))
    spins = 2 * x.astype(np.int8) - 1
    pairs = np.stack([spins[:, i] * spins[:, j] for i, j in edges], axis=1)
    logp = spins @ np.asarray(fields, dtype=np.float64) + coupling * pairs.sum(axis=1)
    p = np.exp(logp - logp.max())
    p /= p.sum()
    return (
        x,
        p,
        {
            "evidence_class": "exact_reference",
            "marginals": (p @ x).tolist(),
            "edge_correlations": (p @ pairs).tolist(),
            "states": len(x),
        },
    )


def cases():
    states, p, _ = exact(np.zeros(N), COUPLING, EDGES)
    result = []
    for seed in (0, 1, 2):
        rng = np.random.default_rng(np.random.SeedSequence([20261001, seed, 41]))
        clean = states[rng.choice(len(states), p=p)]
        noise_draws = rng.random(N)
        for noise in (0.2, 0.35):
            observed = clean ^ (noise_draws < noise)
            fields = ((2 * observed.astype(int) - 1) * (0.5 * np.log((1 - noise) / noise))).astype(
                np.float32
            )
            result.append(
                {
                    "id": f"seed{seed}-noise{noise:g}",
                    "seed": seed,
                    "noise": noise,
                    "clean": clean.astype(int).tolist(),
                    "observed": observed.astype(int).tolist(),
                    "fields": fields.astype(float).tolist(),
                }
            )
    return result


def request():
    return {
        "schema": "ising_denoising_pilot.v1",
        "status": "exploratory",
        "grid": [4, 4],
        "edges": EDGES,
        "coupling": COUPLING,
        "beta": 1.0,
        "cases": cases(),
        "generative_model": "clean image sampled exactly from the zero-field Ising prior; independent binary flips; shared clean image and uniform noise draws within each seed",
        "posterior": "log P(s|y) = sum_edges J*s_i*s_j + sum_i h_i*s_i + constant; h_i=observed_spin*0.5*log((1-noise)/noise)",
        "numeric_dtype": "float32 sampler parameters, float64 enumeration of those same rounded parameters",
        "run_seeds": list(range(RUNS)),
        "horizon_sweeps": HORIZON,
        "budgets": BUDGETS,
        "observations": "initial state plus one state per complete 16-proposal/redraw sweep, 1025 states per chain; correlated",
        "discard_initial_states": DISCARD,
        "retained_states": "at each budget b, sweeps 33..b inclusive; 32/224/992 per chain",
        "samplers": {
            "thrml": "THRML 0.1.4 checkerboard Gibbs, two blocks, fixed order",
            "sequential-gibbs": "independent JAX implementation of single-spin Gibbs, fresh random permutation each sweep",
            "metropolis": "independent JAX implementation of single-spin Metropolis, fresh random permutation each sweep",
        },
        "initialization": "uniform JAX spins; shared initial state across methods; split root into init/sample keys; sample keys fold_in method index",
        "replication": "16 independently seeded chains per fixed case; descriptive summaries, no confidence intervals using correlated states as replicates",
        "metrics": "per-chain/pooled marginal MAE, edge correlations, spin ESS diagnostics, pooled posterior decision Hamming error, Brier score versus clean image",
        "accuracy_limits": "Bayes pixel decisions minimize model-expected Hamming risk; six small images do not establish empirical calibration or general denoising performance",
        "timing": "16-chain JAX batch, one untimed synchronized launch, median of three synchronized launches; compilation separate and shared across cases; initial generation, transfers, scoring and diagnostics excluded",
        "fixture": {
            "fields": [0.2, -0.3, 0.1],
            "coupling": 0.25,
            "edges": [(0, 1), (1, 2)],
            "sweeps": 8192,
            "chains": 4,
            "discard_states": 129,
            "empirical_tv_tolerance": 0.04,
            "kernel_stationarity_tolerance": 1e-12,
        },
        "trace_artifact": "separately SHA-256 hashed packed state arrays in denoise-traces.npz",
        "script_sha256": sha(Path(__file__)),
    }


def key_inputs(index, n, runs=RUNS):
    roots = [
        jax.random.fold_in(jax.random.fold_in(jax.random.key(20261002), index), run)
        for run in range(runs)
    ]
    pairs = [jax.random.split(root) for root in roots]
    initial = jnp.stack([jax.random.bernoulli(a, shape=(n,)) for a, _ in pairs]).block_until_ready()
    return initial, jnp.stack([b for _, b in pairs])


def compile_sampler(method, n, edges, coupling, horizon, keys, initial, fields):
    matrix = np.zeros((n, n), dtype=np.float32)
    for i, j in edges:
        matrix[i, j] = matrix[j, i] = coupling
    matrix = jnp.asarray(matrix)
    if method == "thrml":
        nodes = [SpinNode() for _ in range(n)]
        neighbors = [set() for _ in range(n)]
        for i, j in edges:
            neighbors[i].add(j)
            neighbors[j].add(i)
        colors = []
        for i in range(n):
            used = {colors[j] for j in neighbors[i] if j < i}
            colors.append(next(c for c in range(n) if c not in used))
        partition = [
            np.array([i for i, c in enumerate(colors) if c == color])
            for color in range(max(colors) + 1)
        ]
        assert all(colors[i] != colors[j] for i, j in edges)
        blocks = [Block([nodes[int(i)] for i in color]) for color in partition]
        node_edges = [(nodes[i], nodes[j]) for i, j in edges]
        schedule = SamplingSchedule(0, horizon + 1, 1)

        def single(key, init, bias):
            model = IsingEBM(
                nodes,
                node_edges,
                bias,
                jnp.full(len(edges), coupling, dtype=jnp.float32),
                jnp.float32(1),
            )
            program = IsingSamplingProgram(model, blocks, [])
            return sample_states(
                key, program, schedule, [init[color] for color in partition], [], [Block(nodes)]
            )[0]
    else:

        def single(key, init, bias):
            def sweep(state, sweep_key):
                order_key, update_key = jax.random.split(sweep_key)
                order = jax.random.permutation(order_key, n)
                update_keys = jax.random.split(update_key, n)

                def update(state, item):
                    vertex, rng = item
                    spin = 2 * state.astype(jnp.float32) - 1
                    field = bias[vertex] + matrix[vertex] @ spin
                    u = jax.random.uniform(rng)
                    if method == "sequential-gibbs":
                        value = u < jax.nn.sigmoid(2 * field)
                    else:
                        log_ratio = -2 * spin[vertex] * field
                        value = jnp.where(
                            jnp.log(u) < jnp.minimum(0.0, log_ratio), ~state[vertex], state[vertex]
                        )
                    return state.at[vertex].set(value), None

                state, _ = jax.lax.scan(update, state, (order, update_keys))
                return state, state

            _, draws = jax.lax.scan(sweep, init, jax.random.split(key, horizon))
            return jnp.concatenate([init[None], draws], axis=0)

    function = jax.jit(jax.vmap(single, in_axes=(0, 0, None)))
    started = time.perf_counter()
    executable = function.lower(keys, initial, fields).compile()
    return executable, time.perf_counter() - started


def fixture_check(spec):
    fields = np.asarray(spec["fields"], dtype=np.float32).astype(np.float64)
    coupling = float(np.float32(spec["coupling"]))
    edges = spec["edges"]
    x, p, reference = exact(fields, coupling, edges)
    n = len(fields)
    spin = 2 * x.astype(int) - 1
    matrix = np.zeros((n, n))
    for i, j in edges:
        matrix[i, j] = matrix[j, i] = coupling
    checks = {}
    for method in ("sequential-gibbs", "metropolis"):
        residual = 0.0
        balance = 0.0
        for vertex in range(n):
            kernel = np.zeros((len(x), len(x)))
            for code in range(len(x)):
                field = fields[vertex] + matrix[vertex] @ spin[code]
                other = code ^ (1 << vertex)
                if method == "sequential-gibbs":
                    prob_plus = 1 / (1 + np.exp(-2 * field))
                    transition = prob_plus if not x[code, vertex] else 1 - prob_plus
                else:
                    transition = min(1.0, float(np.exp(-2 * spin[code, vertex] * field)))
                kernel[code, other] = transition
                kernel[code, code] = 1 - transition
            residual = max(residual, float(np.max(np.abs(p @ kernel - p))))
            balance = max(
                balance, float(np.max(np.abs(p[:, None] * kernel - p[None, :] * kernel.T)))
            )
        assert max(residual, balance) <= spec["kernel_stationarity_tolerance"]
        checks[method] = {"stationarity_residual": residual, "detailed_balance_residual": balance}
    initial, root_keys = key_inputs(99, n, spec["chains"])
    traces = {}
    for method_id, method in enumerate(METHODS):
        keys = jax.vmap(lambda key, m=method_id: jax.random.fold_in(key, m))(root_keys)
        executable, _ = compile_sampler(
            method,
            n,
            edges,
            coupling,
            spec["sweeps"],
            keys,
            initial,
            jnp.asarray(fields, dtype=jnp.float32),
        )
        observed = np.asarray(
            executable(keys, initial, jnp.asarray(fields, dtype=jnp.float32)).block_until_ready()
        )
        np.testing.assert_array_equal(observed[:, 0], np.asarray(initial))
        codes = (observed[:, spec["discard_states"] :] * (1 << np.arange(n))).sum(axis=-1)
        empirical = np.bincount(codes.ravel(), minlength=len(x)) / codes.size
        tv = float(np.abs(empirical - p).sum() / 2)
        assert tv < spec["empirical_tv_tolerance"], (method, tv)
        checks[method] = {
            **checks.get(method, {}),
            "empirical_tv": tv,
            "exact": reference,
            "empirical_probabilities": empirical.tolist(),
        }
        traces["fixture__" + method] = np.packbits(observed, axis=-1, bitorder="little")
    return {"passed": True, "methods": checks}, traces


def metrics(case, observed, target):
    assert observed.shape == (RUNS, HORIZON + 1, N)
    exact_p = np.asarray(target["marginals"])
    clean = np.asarray(case["clean"], dtype=bool)
    result = []
    for budget in BUDGETS:
        retained = observed[:, DISCARD : budget + 1]
        probabilities = retained.mean(axis=1)
        pooled = probabilities.mean(axis=0)
        per_chain = np.abs(probabilities - exact_p).mean(axis=1)
        spins = 2 * retained.astype(np.int8) - 1
        pair = np.stack([spins[..., i] * spins[..., j] for i, j in EDGES], axis=-1)
        diagnostics = [
            [diagnose_series(row[:, i]).model_dump(mode="json") for i in range(N)] for row in spins
        ]
        ess = [d["ess"] for row in diagnostics for d in row]
        result.append(
            {
                "sweeps": budget,
                "spin_updates_per_chain": N * budget,
                "retained_states_per_chain": len(retained[0]),
                "marginal_mae_by_chain": per_chain.tolist(),
                "mean_chain_marginal_mae": float(per_chain.mean()),
                "pooled_marginal_mae": float(np.abs(pooled - exact_p).mean()),
                "pooled_pixel_probabilities": pooled.tolist(),
                "pooled_edge_correlation_mae": float(
                    np.abs(pair.mean(axis=(0, 1)) - np.asarray(target["edge_correlations"])).mean()
                ),
                "decision_errors_vs_clean": int(np.sum((pooled > 0.5) != clean)),
                "decision_disagreements_vs_exact": int(np.sum((pooled > 0.5) != (exact_p > 0.5))),
                "brier_vs_clean": float(np.mean((pooled - clean) ** 2)),
                "median_spin_ess": float(np.median(ess)),
                "constant_spin_series": sum(
                    d["status"] == "constant_series" for row in diagnostics for d in row
                ),
                "spin_diagnostics": diagnostics,
            }
        )
    return result


def reference_metrics(case, target):
    clean = np.asarray(case["clean"], dtype=bool)
    noisy = np.asarray(case["observed"], dtype=bool)
    p = np.asarray(target["marginals"])
    return {
        "noisy_pixel_errors": int(np.sum(clean != noisy)),
        "exact_posterior_decision_errors": int(np.sum(clean != (p > 0.5))),
        "exact_posterior_brier": float(np.mean((p - clean) ** 2)),
        "ambiguous_pixels": int(np.sum((p >= 0.25) & (p <= 0.75))),
    }


def report(req, result):
    lines = [
        "# Small Ising posterior-denoising pilot",
        "",
        "Six noisy 4x4 binary images: three exact prior draws at two noise levels. Coupling 0.4, independent pixel-flip noise 0.2/0.35, no training. Posterior references enumerate all 65,536 states using the actual float32 sampler parameters. 16 independently seeded chains per case and method.",
        "",
        "| Case | Method | Noisy errors / 16 | Exact posterior errors | Sample posterior errors | Pooled marginal MAE | Mean chain marginal MAE | Median spin ESS / 992 |",
        "|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    for case in req["cases"]:
        cell = result["cases"][case["id"]]
        for method in METHODS:
            row = cell["methods"][method]["budgets"][-1]
            lines.append(
                f"| {case['id']} | {method} | {cell['reference']['noisy_pixel_errors']} | {cell['reference']['exact_posterior_decision_errors']} | {row['decision_errors_vs_clean']} | {row['pooled_marginal_mae']:.4f} | {row['mean_chain_marginal_mae']:.4f} | {row['median_spin_ess']:.1f} |"
            )
    lines += [
        "",
        "## Descriptive means over the six cases",
        "",
        "| Method | Sweeps | Mean pooled marginal MAE | Mean chain marginal MAE | Mean decision errors / 16 |",
        "|---|---:|---:|---:|---:|",
    ]
    for method in METHODS:
        for index, budget in enumerate(BUDGETS):
            rows = [cell["methods"][method]["budgets"][index] for cell in result["cases"].values()]
            lines.append(
                f"| {method} | {budget} | {np.mean([r['pooled_marginal_mae'] for r in rows]):.4f} | {np.mean([r['mean_chain_marginal_mae'] for r in rows]):.4f} | {np.mean([r['decision_errors_vs_clean'] for r in rows]):.2f} |"
            )
    lines += [
        "",
        "## Scope and accounting",
        "",
        "Each method spends 16 vertex redraws/proposals per sweep. THRML uses checkerboard block Gibbs; the independent Gibbs and Metropolis implementations use random-permutation single-spin sweeps. All target the same posterior and share each run's initial state, with independent sampling keys. Burn-in is fixed at 32 sweeps; observations through sweep 32 are discarded. Short-budget ESS estimates are diagnostics, not convergence guarantees.",
        "",
        "Methods use JAX on CPU. One graph-shaped executable per method is shared across all six cases. Compilation, one untimed launch and median of three synchronized batch launches are separate; batch execution covers 16 chains, excludes initialization, transfers and metric extraction. Work counts are algorithmic, not equal device operations or energy. All sampler outputs are software_simulation; exact posterior references are exact_reference.",
        "",
        "The clean images were drawn from the stated prior, so this tests inference in a small correctly specified model. Posterior pixel decisions minimize expected Hamming error under that model, but may worsen any particular realized image. Three prior draws with two coupled noise levels do not establish calibration, real-image quality, scaling or sampler superiority. Probabilities are checked directly against exact marginals; lower pixel errors alone do not prove accurate uncertainty.",
        "",
        "request.json pins all images and parameters. Per-chain metrics, Brier scores, edge errors and diagnostic statuses are in denoise-results.json. Packed traces have a separate SHA-256. Fixture checks validate exact detailed balance of conventional single-site kernels and every sampler against an eight-state model. Evidence replay checks every saved metric, exact reference and fixture distribution; it does not regenerate the stochastic trajectories or timings.",
    ]
    return "\n".join(lines) + "\n"


def run():
    if (OUT / "denoise-results.json").exists():
        raise FileExistsError("results exist; use --replay")
    assert jax.default_backend() == "cpu" and importlib.metadata.version("thrml") == "0.1.4"
    started = time.perf_counter()
    req = request()
    write("denoise-request.json", {"request": req, "request_digest": canonical_sha256(req)})
    fixture, saved = fixture_check(req["fixture"])
    print("Fixture TV", {k: v["empirical_tv"] for k, v in fixture["methods"].items()}, flush=True)
    result = {
        "request_digest": canonical_sha256(req),
        "fixture": fixture,
        "cases": {},
        "compile_seconds": {},
        "runtime": {
            "python": platform.python_version(),
            "packages": {
                name: importlib.metadata.version(name)
                for name in ("jax", "jaxlib", "thrml", "numpy", "scipy")
            },
            "jax_backend": jax.default_backend(),
            "jax_devices": [str(d) for d in jax.devices()],
            "jax_enable_x64": bool(jax.config.jax_enable_x64),
            "git_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
            "git_dirty": bool(
                subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
            ),
            "cpu_quota": Path("/sys/fs/cgroup/cpu.max").read_text().strip(),
            "memory_limit_bytes": Path("/sys/fs/cgroup/memory.max").read_text().strip(),
        },
    }
    first_init, first_keys = key_inputs(0, N)
    executables = {}
    for method in METHODS:
        executable, compile_seconds = compile_sampler(
            method,
            N,
            EDGES,
            COUPLING,
            HORIZON,
            first_keys,
            first_init,
            jnp.asarray(req["cases"][0]["fields"], dtype=jnp.float32),
        )
        executables[method] = executable
        result["compile_seconds"][method] = compile_seconds
    for index, case in enumerate(req["cases"]):
        _, _, target = exact(case["fields"], COUPLING, EDGES)
        cell = {"exact": target, "reference": reference_metrics(case, target), "methods": {}}
        initial, root_keys = key_inputs(index, N)
        fields = jnp.asarray(case["fields"], dtype=jnp.float32)
        for method_id, method in enumerate(METHODS):
            keys = jax.vmap(lambda key, m=method_id: jax.random.fold_in(key, m))(root_keys)
            executable = executables[method]
            executable(keys, initial, fields).block_until_ready()
            timings = []
            for _ in range(3):
                t = time.perf_counter()
                states = executable(keys, initial, fields).block_until_ready()
                timings.append(time.perf_counter() - t)
            observed = np.asarray(states)
            np.testing.assert_array_equal(observed[:, 0], np.asarray(initial))
            saved[case["id"] + "__" + method] = np.packbits(observed, axis=-1, bitorder="little")
            cell["methods"][method] = {
                "evidence_class": "software_simulation",
                "batch_execution_seconds": float(np.median(timings)),
                "launch_seconds": timings,
                "budgets": metrics(case, observed, target),
            }
        result["cases"][case["id"]] = cell
        print(
            case["id"],
            "pixel errors noisy/exact",
            cell["reference"]["noisy_pixel_errors"],
            cell["reference"]["exact_posterior_decision_errors"],
            "MAE",
            {
                k: round(v["budgets"][-1]["pooled_marginal_mae"], 5)
                for k, v in cell["methods"].items()
            },
            flush=True,
        )
    np.savez_compressed(OUT / "denoise-traces.npz", **saved)
    result["trace_sha256"] = sha(OUT / "denoise-traces.npz")
    result["generation_seconds"] = time.perf_counter() - started
    write("denoise-results.json", result)
    (OUT / "denoise-report.md").write_text(report(req, result))
    print(
        f"Denoising generation complete in {result['generation_seconds']:.2f}s; replay required",
        flush=True,
    )


def replay():
    started = time.perf_counter()
    frozen = json.loads((OUT / "denoise-request.json").read_text())
    req = frozen["request"]
    assert req == json.loads(json.dumps(request()))
    assert frozen["request_digest"] == canonical_sha256(req)
    result = json.loads((OUT / "denoise-results.json").read_text())
    assert result["request_digest"] == frozen["request_digest"]
    assert result["trace_sha256"] == sha(OUT / "denoise-traces.npz")
    with np.load(OUT / "denoise-traces.npz", allow_pickle=False) as traces:
        _, fixture_p, fixture_exact = exact(
            np.asarray(req["fixture"]["fields"], dtype=np.float32).astype(float),
            float(np.float32(req["fixture"]["coupling"])),
            req["fixture"]["edges"],
        )
        for method in METHODS:
            observed = np.unpackbits(
                traces["fixture__" + method], axis=-1, count=3, bitorder="little"
            ).astype(bool)
            codes = (observed[:, req["fixture"]["discard_states"] :] * (1 << np.arange(3))).sum(
                axis=-1
            )
            empirical = np.bincount(codes.ravel(), minlength=8) / codes.size
            stored = result["fixture"]["methods"][method]
            assert stored["exact"] == fixture_exact
            np.testing.assert_array_equal(empirical, stored["empirical_probabilities"])
            assert float(np.abs(empirical - fixture_p).sum() / 2) == stored["empirical_tv"]
        for index, case in enumerate(req["cases"]):
            _, _, target = exact(case["fields"], COUPLING, EDGES)
            stored = result["cases"][case["id"]]
            assert stored["exact"] == target and stored["reference"] == reference_metrics(
                case, target
            )
            initial, _ = key_inputs(index, N)
            for method in METHODS:
                observed = np.unpackbits(
                    traces[case["id"] + "__" + method], axis=-1, count=N, bitorder="little"
                ).astype(bool)
                np.testing.assert_array_equal(observed[:, 0], np.asarray(initial))
                assert metrics(case, observed, target) == stored["methods"][method]["budgets"]
    assert (OUT / "denoise-report.md").read_text() == report(req, result)
    write(
        "denoise-completion.json",
        {
            "status": "exploratory_denoise_complete",
            "replayed": True,
            "cases": 6,
            "methods": 3,
            "chains_per_case_method": RUNS,
            "request_digest": canonical_sha256(req),
            "results_sha256": sha(OUT / "denoise-results.json"),
            "trace_sha256": result["trace_sha256"],
            "replay_seconds": time.perf_counter() - started,
            "scope": "all exact posterior references, saved fixture probabilities, initial states and all per-chain/pool metrics; stochastic trajectories not regenerated",
        },
    )
    print("Denoising replay passed: every exact reference and saved metric", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    try:
        replay() if args.replay else run()
    except Exception as exc:
        write("denoise-failure.json", {"type": type(exc).__name__, "message": str(exc)})
        raise
