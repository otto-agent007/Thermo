# Inference pilot: saved-chain analysis and exact-posterior denoising

Both stages completed on CPU and passed independent evidence replay. No tracked repository files or dependency lockfiles were changed.

## What we learned

1. Finding a good cut does not establish good sampling. In the saved beta-4 Max-Cut chains, 994 of 1,344 spin series stayed constant over the retained 192 sweeps. The median across six graphs of median chain marginal probability error was 0.4751, against 0.0788 at beta 1 and 0.0299 at beta 0.25. Exact zero-field marginals are 0.5 by global spin-flip symmetry, so pooling opposite modes can mask individual-chain trapping. This is a short-chain diagnostic, not a universal temperature result or stationary-distribution guarantee.

2. Posterior inference is feasible and cheap at this scale. On six 4x4 noisy images, THRML mean pooled pixel-probability MAE at 1,024 sweeps was 0.00334 (0.334 percentage points), independent random-permutation Gibbs 0.00400, and random-permutation Metropolis 0.00279. Per-chain MAEs were 0.0155, 0.0160 and 0.0123; pooled probabilities use 16 independently seeded chains per fixed case. These descriptive points establish no sampler superiority.

3. An accurate posterior need not reconstruct every realized image correctly. Exact posterior pixel decisions reduced total errors from 26 to 20 over 96 pixels, but worsened one case from 5 to 6. THRML and Metropolis had 19 errors and independent Gibbs 21; each differed from the exact decision on one near-threshold pixel. That accidental truth-label difference is not evidence of beating the exact Bayes decision. Posterior sampling error and model/data ambiguity remain separate.

The cases use only three exact draws from a small Ising prior, each with two coupled noise levels. This checks inference in a correctly specified model and does not establish real-image denoising quality, calibration or scaling. All samplers are software_simulation and all enumerated references exact_reference. No hardware performance claim.

## Artifacts

- analysis-report.md / analysis.json: all 18 graph-temperature comparisons, exact moments and per-chain diagnostics.
- denoise-report.md / denoise-results.json: all six cases, three methods and three budgets; per-chain marginal, edge, Brier and ESS diagnostics.
- denoising.png/pdf: clean/noisy pixels alongside exact, THRML and Metropolis posterior probability maps.
- posterior-accuracy.png/pdf: pooled and individual-chain error versus update budget.
- saved-chain-mixing.png/pdf: short-chain mixing diagnostics by temperature.
- source/: immutable, hash-authenticated prior Max-Cut pilot.
- denoise-traces.npz: separately hashed packed trajectories, including small-model fixtures.
- *completion.json: replay scopes and artifact hashes.

Generation of the denoising pilot took 8.106 seconds and denoising evidence replay 1.053 seconds, excluding interpreter startup and environment setup. Generation includes exact enumeration, fixture validation, compilation, initialization, all repeated synchronized launches, diagnostics and artifact writes. Sampler batch timing scopes are narrower and explicitly defined in denoise-request.json. The session had a 4-CPU quota and 16-GiB memory limit. These are evaluator observations, not hardware sample rates or device latency.

## Reproduce

From the Thermo repository root and its frozen environment:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 JAX_PLATFORMS=cpu uv run --frozen python results/inference-pilot-2026-10-01/analyze.py --replay
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 JAX_PLATFORMS=cpu uv run --frozen python results/inference-pilot-2026-10-01/denoise.py --replay
```

To regenerate, copy analyze.py, denoise.py and source/ unchanged into a fresh ignored results directory, then run each script without --replay and follow with --replay. Existing records are never overwritten during generation. The scripts pin their own hashes in requests. Figure generation uses plot_results.py with a Python environment containing matplotlib and NumPy; the cloud's system environment supplied those without changing the project dependencies.

Replay recomputes all exact references and every recorded quality/diagnostic metric and checks hashes, fixture probabilities and initialization. It does not regenerate THRML, Gibbs or Metropolis trajectories or reproduce wall-clock timings.
