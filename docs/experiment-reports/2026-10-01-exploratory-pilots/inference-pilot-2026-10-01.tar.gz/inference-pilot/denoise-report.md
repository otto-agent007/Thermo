# Small Ising posterior-denoising pilot

Six noisy 4x4 binary images: three exact prior draws at two noise levels. Coupling 0.4, independent pixel-flip noise 0.2/0.35, no training. Posterior references enumerate all 65,536 states using the actual float32 sampler parameters. 16 independently seeded chains per case and method.

| Case | Method | Noisy errors / 16 | Exact posterior errors | Sample posterior errors | Pooled marginal MAE | Mean chain marginal MAE | Median spin ESS / 992 |
|---|---|---:|---:|---:|---:|---:|---:|
| seed0-noise0.2 | thrml | 3 | 1 | 1 | 0.0021 | 0.0080 | 733.5 |
| seed0-noise0.2 | sequential-gibbs | 3 | 1 | 1 | 0.0027 | 0.0091 | 723.1 |
| seed0-noise0.2 | metropolis | 3 | 1 | 1 | 0.0017 | 0.0068 | 992.0 |
| seed0-noise0.35 | thrml | 5 | 0 | 0 | 0.0059 | 0.0234 | 324.7 |
| seed0-noise0.35 | sequential-gibbs | 5 | 0 | 1 | 0.0046 | 0.0172 | 289.6 |
| seed0-noise0.35 | metropolis | 5 | 0 | 0 | 0.0026 | 0.0185 | 556.8 |
| seed1-noise0.2 | thrml | 4 | 4 | 4 | 0.0044 | 0.0166 | 532.7 |
| seed1-noise0.2 | sequential-gibbs | 4 | 4 | 4 | 0.0035 | 0.0134 | 497.0 |
| seed1-noise0.2 | metropolis | 4 | 4 | 4 | 0.0034 | 0.0119 | 923.3 |
| seed1-noise0.35 | thrml | 5 | 6 | 6 | 0.0029 | 0.0156 | 341.8 |
| seed1-noise0.35 | sequential-gibbs | 5 | 6 | 6 | 0.0084 | 0.0218 | 306.3 |
| seed1-noise0.35 | metropolis | 5 | 6 | 6 | 0.0040 | 0.0136 | 520.5 |
| seed2-noise0.2 | thrml | 3 | 3 | 3 | 0.0024 | 0.0091 | 730.8 |
| seed2-noise0.2 | sequential-gibbs | 3 | 3 | 3 | 0.0022 | 0.0095 | 688.9 |
| seed2-noise0.2 | metropolis | 3 | 3 | 3 | 0.0019 | 0.0079 | 992.0 |
| seed2-noise0.35 | thrml | 6 | 6 | 5 | 0.0024 | 0.0204 | 311.0 |
| seed2-noise0.35 | sequential-gibbs | 6 | 6 | 6 | 0.0026 | 0.0252 | 280.8 |
| seed2-noise0.35 | metropolis | 6 | 6 | 5 | 0.0031 | 0.0150 | 531.4 |

## Descriptive means over the six cases

| Method | Sweeps | Mean pooled marginal MAE | Mean chain marginal MAE | Mean decision errors / 16 |
|---|---:|---:|---:|---:|
| thrml | 64 | 0.0175 | 0.0921 | 3.33 |
| thrml | 256 | 0.0074 | 0.0336 | 3.17 |
| thrml | 1024 | 0.0033 | 0.0155 | 3.17 |
| sequential-gibbs | 64 | 0.0197 | 0.0916 | 3.50 |
| sequential-gibbs | 256 | 0.0075 | 0.0392 | 3.50 |
| sequential-gibbs | 1024 | 0.0040 | 0.0160 | 3.50 |
| metropolis | 64 | 0.0145 | 0.0665 | 3.50 |
| metropolis | 256 | 0.0093 | 0.0269 | 3.17 |
| metropolis | 1024 | 0.0028 | 0.0123 | 3.17 |

## Scope and accounting

Each method spends 16 vertex redraws/proposals per sweep. THRML uses checkerboard block Gibbs; the independent Gibbs and Metropolis implementations use random-permutation single-spin sweeps. All target the same posterior and share each run's initial state, with independent sampling keys. Burn-in is fixed at 32 sweeps; observations through sweep 32 are discarded. Short-budget ESS estimates are diagnostics, not convergence guarantees.

Methods use JAX on CPU. One graph-shaped executable per method is shared across all six cases. Compilation, one untimed launch and median of three synchronized batch launches are separate; batch execution covers 16 chains, excludes initialization, transfers and metric extraction. Work counts are algorithmic, not equal device operations or energy. All sampler outputs are software_simulation; exact posterior references are exact_reference.

The clean images were drawn from the stated prior, so this tests inference in a small correctly specified model. Posterior pixel decisions minimize expected Hamming error under that model, but may worsen any particular realized image. Three prior draws with two coupled noise levels do not establish calibration, real-image quality, scaling or sampler superiority. Probabilities are checked directly against exact marginals; lower pixel errors alone do not prove accurate uncertainty.

request.json pins all images and parameters. Per-chain metrics, Brier scores, edge errors and diagnostic statuses are in denoise-results.json. Packed traces have a separate SHA-256. Fixture checks validate exact detailed balance of conventional single-site kernels and every sampler against an eight-state model. Evidence replay checks every saved metric, exact reference and fixture distribution; it does not regenerate the stochastic trajectories or timings.
