"""Exploratory random-restart greedy comparison; no production code changes."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import platform
import subprocess
import time
from pathlib import Path

import numpy as np

from thermo_lab.hashing import canonical_sha256

OUT = Path(__file__).resolve().parent
SOURCE = OUT / "source"
FILES = ("pilot.py", "request.json", "results.json", "traces.npz", "completion.json", "report.md")
spec = importlib.util.spec_from_file_location("source_pilot", SOURCE / "pilot.py")
pilot = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pilot)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    path = OUT / name
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temp.replace(path)


def load_source():
    frozen = json.loads((SOURCE / "request.json").read_text())
    result = json.loads((SOURCE / "results.json").read_text())
    completion = json.loads((SOURCE / "completion.json").read_text())
    assert canonical_sha256(frozen["request"]) == frozen["request_digest"]
    assert result["request_digest"] == completion["request_digest"] == frozen["request_digest"]
    assert sha(SOURCE / "results.json") == completion["results_sha256"]
    assert sha(SOURCE / "traces.npz") == completion["trace_sha256"] == result["trace_sha256"]
    assert sha(SOURCE / "pilot.py") == frozen["request"]["script_sha256"]
    assert completion["status"] == "exploratory_pilot_complete" and completion["replayed"]
    with np.load(SOURCE / "traces.npz", allow_pickle=False) as traces:
        for g in frozen["request"]["graphs"]:
            old = result["graphs"][g["id"]]
            exact = pilot.exact(g)
            assert exact["optimum"] == old["exact"]["optimum"]
            initial = None
            for name, arm in old["methods"].items():
                states = np.unpackbits(
                    traces[f"{g['id']}__{name}"], axis=-1, count=g["n"], bitorder="little"
                ).astype(bool)
                work = traces[f"{g['id']}__{name}__work"]
                assert pilot.metrics(g, states, work, exact["optimum"]) == arm["budgets"]
                if initial is None:
                    initial = states[:, 0]
                else:
                    np.testing.assert_array_equal(initial, states[:, 0])
    return frozen, result


def request(frozen):
    return {
        "schema": "maxcut_restart_greedy.v1",
        "status": "exploratory",
        "source_request_digest": frozen["request_digest"],
        "source_sha256": {name: sha(SOURCE / name) for name in FILES},
        "graphs": frozen["request"]["graphs"],
        "run_seeds": list(range(pilot.RUNS)),
        "budgets_sweeps_equivalent": pilot.BUDGETS,
        "proposal_budget": "n * original sweep budget, per graph and run",
        "algorithm": "strict positive-gain single-spin flips in random-permutation sweeps; after a no-flip sweep, restart uniformly at the start of the next sweep",
        "random_policy": "NumPy SeedSequence([20261001, graph_index, run_seed, 7]); same permutation stream as original greedy up to first restart",
        "initialization": "same saved initial state as all original methods; additional restarts draw n independent uniform bits",
        "observation": "initial state and every complete sweep endpoint; best seen over all restarts; no early stop on known optimum",
        "work": "every vertex proposal counted, including no-flip sweeps; full budget spent; restart count and additional random initialization bits reported separately",
        "budget_matching_limit": "equal attempted vertex updates only; Gibbs redraw and greedy proposal have different cost; restart random bits and host costs excluded from matched count",
        "comparison": "reuse all source sampler and baseline observations, show every saved budget; no THRML rerun or temperature retuning",
        "evidence_class": "software_simulation; exact optima remain exact_reference",
        "trace_artifact": "SHA-256 hashed packed sweep-end states and cumulative restarts in traces.npz",
        "timing_scope": "Python/NumPy 16-run batch, includes initialization copies, restarts, gain computations and trajectory/ledger writes; excludes source replay, exact enumeration and metric extraction",
        "script_sha256": sha(Path(__file__)),
    }


def restart_greedy(g, initial, index, *, horizon=pilot.HORIZON, check_gains=False):
    neighbors = [[] for _ in range(g["n"])]
    for (a, b), weight in zip(g["edges"], g["weights"], strict=True):
        neighbors[a].append((b, weight))
        neighbors[b].append((a, weight))
    runs = len(initial)
    states = np.empty((runs, horizon + 1, g["n"]), dtype=bool)
    restarts = np.zeros((runs, horizon + 1), dtype=np.int64)
    started = time.perf_counter()
    for run in range(runs):
        rng = np.random.default_rng(np.random.SeedSequence([20261001, index, run, 7]))
        spin = 2 * initial[run].astype(np.int64) - 1
        states[run, 0] = spin > 0
        needs_restart = False
        for sweep in range(1, horizon + 1):
            restarts[run, sweep] = restarts[run, sweep - 1]
            if needs_restart:
                spin = 2 * rng.integers(0, 2, g["n"]) - 1
                restarts[run, sweep] += 1
            flips = 0
            for vertex in rng.permutation(g["n"]):
                gain = sum(
                    weight * spin[vertex] * spin[other] for other, weight in neighbors[vertex]
                )
                if check_gains:
                    candidate = spin.copy()
                    candidate[vertex] *= -1
                    assert gain == int(pilot.cut(candidate > 0, g) - pilot.cut(spin > 0, g))
                if gain > 0:
                    spin[vertex] *= -1
                    flips += 1
            needs_restart = flips == 0
            states[run, sweep] = spin > 0
    work = np.broadcast_to(np.arange(horizon + 1) * g["n"], (runs, horizon + 1)).copy()
    return states, work, restarts, time.perf_counter() - started


def fixture_check():
    g = {"n": 3, "edges": [[0, 1], [0, 2], [1, 2]], "weights": [1, 2, 3]}
    initial = pilot.all_states(3)
    states, work, restarts, _ = restart_greedy(g, initial, 99, horizon=16, check_gains=True)
    np.testing.assert_array_equal(states[:, 0], initial)
    np.testing.assert_array_equal(work, np.broadcast_to(np.arange(17) * 3, (8, 17)))
    assert restarts[:, 0].max() == 0 and (restarts[:, -1] > 0).all()
    assert (np.diff(restarts, axis=1) >= 0).all()
    assert int(pilot.cut(states, g).max()) == 5
    assert (pilot.cut(states, g)[:, 1:].max(axis=1) == 5).all()
    np.testing.assert_array_equal(states, restart_greedy(g, initial, 99, horizon=16)[0])
    return {
        "passed": True,
        "states": 8,
        "sweeps": 16,
        "checks": [
            "gain sign versus independent edge scoring at every proposal",
            "known optimum",
            "exact work count",
            "restart occurrence",
            "determinism",
        ],
    }


def runtime():
    assert pilot.jax.default_backend() == "cpu"
    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "packages": {
            name: importlib.metadata.version(name)
            for name in ("jax", "jaxlib", "thrml", "numpy", "scipy")
        },
        "jax_backend": pilot.jax.default_backend(),
        "jax_devices": [str(device) for device in pilot.jax.devices()],
        "jax_enable_x64": bool(pilot.jax.config.jax_enable_x64),
        "git_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "git_dirty": bool(
            subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
        ),
        "cpu_quota": Path("/sys/fs/cgroup/cpu.max").read_text().strip(),
        "memory_limit_bytes": Path("/sys/fs/cgroup/memory.max").read_text().strip(),
    }


def metrics(g, states, work, restarts, optimum):
    rows = pilot.metrics(g, states, work, optimum)
    for row in rows:
        b = row["sweeps"]
        row["restarts_by_run"] = restarts[:, b].tolist()
        row["additional_random_initialization_bits_by_run"] = (restarts[:, b] * g["n"]).tolist()
    return rows


def aggregate(req, source, result):
    names = list(source["graphs"][req["graphs"][0]["id"]]["methods"]) + ["restart-greedy"]
    rows = []
    for name in names:
        for index, b in enumerate(pilot.BUDGETS):
            cells = [
                (
                    result["graphs"][g["id"]]
                    if name == "restart-greedy"
                    else source["graphs"][g["id"]]["methods"][name]
                )["budgets"][index]
                for g in req["graphs"]
            ]
            rows.append(
                {
                    "method": name,
                    "budget_sweeps_equivalent": b,
                    "optimum_hits": sum(c["optimum_hits"] for c in cells),
                    "runs": len(cells) * pilot.RUNS,
                    "mean_relative_gap": float(np.mean([c["mean_relative_gap"] for c in cells])),
                    "mean_proposals_or_redraws": float(
                        np.mean([w for c in cells for w in c["work_by_run"]])
                    ),
                    "mean_restarts": float(
                        np.mean(
                            [w for c in cells for w in c.get("restarts_by_run", [0] * pilot.RUNS)]
                        )
                    ),
                }
            )
    return rows


def report(req, source, result):
    rows = aggregate(req, source, result)
    lines = [
        "# Random-restart greedy versus THRML",
        "",
        "Exploratory CPU follow-up on the same six weighted degree-3 graphs (12 or 16 vertices), exact optima and 16 run seeds per graph from the authenticated source pilot.",
        "",
        "Random-restart greedy flips strictly positive-gain vertices in random-permutation sweeps. After a no-flip sweep it draws a fresh uniform state before the next sweep. Every proposal counts, including no-flip sweeps. Known optima never stop the search. All methods share the first initial state and observe only initial/sweep-end states.",
        "",
        "## Budget comparison",
        "",
        "| Method | Sweep-equivalent budget | Optimum hits / 96 | Mean relative gap | Mean proposals/redraws | Mean restarts |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            f"| {row['method']} | {row['budget_sweeps_equivalent']} | "
            f"{row['optimum_hits']}/96 | {row['mean_relative_gap']:.5f} | "
            f"{row['mean_proposals_or_redraws']:.1f} | {row['mean_restarts']:.1f} |"
        )
    lines += [
        "",
        "## Per-graph results at the full budget",
        "",
        "| Graph | Exact optimum | Restart greedy hits / 16 | THRML beta 1 hits / 16 | Annealing hits / 16 | Restart greedy CPU batch seconds |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for g in req["graphs"]:
        cell = result["graphs"][g["id"]]
        old = source["graphs"][g["id"]]
        lines.append(
            f"| {g['id']} | {old['exact']['optimum']} | "
            f"{cell['budgets'][-1]['optimum_hits']}/16 | "
            f"{old['methods']['thrml-beta-1']['budgets'][-1]['optimum_hits']}/16 | "
            f"{old['methods']['anneal']['budgets'][-1]['optimum_hits']}/16 | "
            f"{cell['batch_execution_seconds']:.6f} |"
        )
    lines += [
        "",
        "## Interpretation and limits",
        "",
        "Budgets match attempted vertex updates, not equal wall time, RNG cost, energy or device operations. Greedy additionally generates and writes n random initialization bits at every restart; these counts are recorded separately. The original single-start greedy stops early and spends much less work. Gibbs redraws and greedy gain tests differ computationally.",
        "",
        "Source THRML/annealing results are reused, not regenerated. Annealing's short-budget points are prefixes of its original 256-sweep temperature ramp; schedules are not tuned separately for each budget. All three source THRML temperatures are displayed. The moderate temperature was identified on these same graphs, so this is exploratory, not held-out evidence.",
        "",
        "CPU batch timings are observations for this Python/NumPy implementation and include restart generation, gain computations and trace recording for 16 runs. Initialization copying is included; exact enumeration, source replay and final metric extraction are excluded. Do not interpret timings against JAX launches with different timed scopes as algorithmic speedups.",
        "",
        "All heuristic/sampler outcomes are software_simulation and optima exact_reference. Six small graphs from one family do not establish scaling. Replay authenticates source artifacts, recomputes all old/new quality and work metrics, and regenerates every new baseline trajectory. Full per-run details and additional random-bit counts are in results.json; traces are separately hashed.",
    ]
    return "\n".join(lines) + "\n"


def run():
    if (OUT / "results.json").exists():
        raise FileExistsError("results already exist; use --replay")
    started = time.perf_counter()
    frozen, source = load_source()
    req = request(frozen)
    write("request.json", {"request": req, "request_digest": canonical_sha256(req)})
    result = {
        "request_digest": canonical_sha256(req),
        "fixture": fixture_check(),
        "graphs": {},
        "runtime": runtime(),
    }
    saved = {}
    with np.load(SOURCE / "traces.npz", allow_pickle=False) as traces:
        for index, g in enumerate(req["graphs"]):
            initial = np.unpackbits(
                traces[f"{g['id']}__greedy"], axis=-1, count=g["n"], bitorder="little"
            ).astype(bool)[:, 0]
            states, work, restarts, elapsed = restart_greedy(g, initial, index)
            # It must match the old greedy until the first restart, across all seeds.
            old = np.unpackbits(
                traces[f"{g['id']}__greedy"], axis=-1, count=g["n"], bitorder="little"
            ).astype(bool)
            for run in range(pilot.RUNS):
                positions = np.flatnonzero(restarts[run])
                end = int(positions[0]) if len(positions) else pilot.HORIZON + 1
                np.testing.assert_array_equal(states[run, :end], old[run, :end])
            cell = {
                "evidence_class": "software_simulation",
                "work_unit": "spin_proposals",
                "batch_execution_seconds": elapsed,
                "budgets": metrics(
                    g, states, work, restarts, source["graphs"][g["id"]]["exact"]["optimum"]
                ),
            }
            result["graphs"][g["id"]] = cell
            saved[g["id"]] = np.packbits(states, axis=-1, bitorder="little")
            saved[g["id"] + "__restarts"] = restarts
            print(
                g["id"],
                "hits by budget",
                [row["optimum_hits"] for row in cell["budgets"]],
                flush=True,
            )
    np.savez_compressed(OUT / "traces.npz", **saved)
    result["trace_sha256"] = sha(OUT / "traces.npz")
    result["aggregate"] = aggregate(req, source, result)
    result["generation_seconds"] = time.perf_counter() - started
    write("results.json", result)
    (OUT / "report.md").write_text(report(req, source, result))
    print(
        f"Generation complete in {result['generation_seconds']:.3f}s; replay required", flush=True
    )


def replay():
    started = time.perf_counter()
    source_frozen, source = load_source()
    frozen = json.loads((OUT / "request.json").read_text())
    req = frozen["request"]
    assert req == json.loads(json.dumps(request(source_frozen)))
    assert canonical_sha256(req) == frozen["request_digest"]
    result = json.loads((OUT / "results.json").read_text())
    assert result["request_digest"] == frozen["request_digest"]
    assert sha(OUT / "traces.npz") == result["trace_sha256"]
    assert fixture_check() == result["fixture"]
    with np.load(OUT / "traces.npz", allow_pickle=False) as traces:
        for index, g in enumerate(req["graphs"]):
            states = np.unpackbits(
                traces[g["id"]], axis=-1, count=g["n"], bitorder="little"
            ).astype(bool)
            with np.load(SOURCE / "traces.npz", allow_pickle=False) as prior:
                initial = np.unpackbits(
                    prior[f"{g['id']}__greedy"], axis=-1, count=g["n"], bitorder="little"
                ).astype(bool)[:, 0]
            np.testing.assert_array_equal(states[:, 0], initial)
            work = np.broadcast_to(
                np.arange(pilot.HORIZON + 1) * g["n"], (pilot.RUNS, pilot.HORIZON + 1)
            )
            restarts = traces[g["id"] + "__restarts"]
            regenerated, work2, restarts2, _ = restart_greedy(g, states[:, 0], index)
            np.testing.assert_array_equal(states, regenerated)
            np.testing.assert_array_equal(work, work2)
            np.testing.assert_array_equal(restarts, restarts2)
            optimum = pilot.exact(g)["optimum"]
            assert (
                metrics(g, states, work, restarts, optimum) == result["graphs"][g["id"]]["budgets"]
            )
    assert aggregate(req, source, result) == result["aggregate"]
    assert (OUT / "report.md").read_text() == report(req, source, result)
    write(
        "completion.json",
        {
            "status": "exploratory_restart_comparison_complete",
            "replayed": True,
            "graphs": 6,
            "new_runs": 96,
            "budget_points": len(pilot.BUDGETS),
            "source_request_digest": source_frozen["request_digest"],
            "request_digest": canonical_sha256(req),
            "results_sha256": sha(OUT / "results.json"),
            "trace_sha256": result["trace_sha256"],
            "replay_seconds": time.perf_counter() - started,
            "scope": "authenticated source; exact optima and all old/new quality/work metrics; all new greedy trajectories regenerated; prior THRML trajectories reused",
        },
    )
    print(
        "Replay passed: source hashes, exact optima, every budget metric and every new trajectory",
        flush=True,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    try:
        replay() if args.replay else run()
    except Exception as exc:
        write("failure.json", {"type": type(exc).__name__, "message": str(exc)})
        raise
