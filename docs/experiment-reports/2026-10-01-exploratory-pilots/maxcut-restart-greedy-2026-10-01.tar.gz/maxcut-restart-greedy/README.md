# Random-restart greedy Max-Cut comparison

Result: on the same six 12/16-vertex weighted sparse graphs, random-restart greedy is competitive with THRML. At 16 sweep-equivalent budgets it finds 63/96 optima, against 61/96 for THRML beta 1; mean gaps are 1.85% and 1.75% respectively. At 64 it finds 93/96 versus 87/96 for THRML and 70/96 for the original annealer. At 256 all three find 96/96.

The original single-start greedy hit 20/96 but spent only about 37 proposals per run. The new baseline spends the full attempted-update budget and restarts after no-flip sweeps. This changes the interpretation of the first pilot: stochastic sampling has no demonstrated solution-quality advantage over this stronger simple baseline on these instances. It does not establish that greedy is generally better, and nothing here is a hardware or speed advantage.

Read report.md for every method/budget, per-graph results and accounting limits. Restarts draw additional uniform bits, recorded separately in results.json. Matching vertex-update counts is not matching runtime, RNG work, energy or device operations. The earlier annealer's short budgets are prefixes of its 256-sweep schedule.

Generation took 0.609 seconds and evidence replay 0.583 seconds, excluding Python startup/environment setup. Those scopes include the source checks and validations; method batch timings are separately scoped in request.json.

Replay from the repository root with the frozen environment:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 JAX_PLATFORMS=cpu uv run --frozen python results/maxcut-restart-greedy-2026-10-01/compare.py --replay
```

To repeat generation, copy compare.py unchanged and the source/ directory to a new ignored results subdirectory. Run that copy, then invoke it with --replay. Existing results.json is never overwritten during generation. request.json pins compare.py and every immutable source artifact.

completion.json authenticates the results and trace hashes after independent replay. Replay recomputes all old/new quality and work metrics, exact optima and every new trajectory. THRML observations are reused from the authenticated pilot; no sampler retuning or new THRML runs were performed. All outcomes remain exploratory software simulations on one small graph family.

No tracked repository file was changed.
