# Random-restart greedy versus THRML

Exploratory CPU follow-up on the same six weighted degree-3 graphs (12 or 16 vertices), exact optima and 16 run seeds per graph from the authenticated source pilot.

Random-restart greedy flips strictly positive-gain vertices in random-permutation sweeps. After a no-flip sweep it draws a fresh uniform state before the next sweep. Every proposal counts, including no-flip sweeps. Known optima never stop the search. All methods share the first initial state and observe only initial/sweep-end states.

## Budget comparison

| Method | Sweep-equivalent budget | Optimum hits / 96 | Mean relative gap | Mean proposals/redraws | Mean restarts |
|---|---:|---:|---:|---:|---:|
| anneal | 1 | 0/96 | 0.42062 | 14.0 | 0.0 |
| anneal | 4 | 0/96 | 0.32939 | 56.0 | 0.0 |
| anneal | 16 | 3/96 | 0.16201 | 224.0 | 0.0 |
| anneal | 64 | 70/96 | 0.00986 | 896.0 | 0.0 |
| anneal | 256 | 96/96 | 0.00000 | 3584.0 | 0.0 |
| greedy | 1 | 9/96 | 0.12627 | 14.0 | 0.0 |
| greedy | 4 | 19/96 | 0.08276 | 36.6 | 0.0 |
| greedy | 16 | 20/96 | 0.08195 | 37.1 | 0.0 |
| greedy | 64 | 20/96 | 0.08195 | 37.1 | 0.0 |
| greedy | 256 | 20/96 | 0.08195 | 37.1 | 0.0 |
| thrml-beta-0.25 | 1 | 1/96 | 0.34041 | 14.0 | 0.0 |
| thrml-beta-0.25 | 4 | 1/96 | 0.23054 | 56.0 | 0.0 |
| thrml-beta-0.25 | 16 | 3/96 | 0.15152 | 224.0 | 0.0 |
| thrml-beta-0.25 | 64 | 13/96 | 0.08528 | 896.0 | 0.0 |
| thrml-beta-0.25 | 256 | 35/96 | 0.04013 | 3584.0 | 0.0 |
| thrml-beta-1 | 1 | 5/96 | 0.20389 | 14.0 | 0.0 |
| thrml-beta-1 | 4 | 23/96 | 0.08660 | 56.0 | 0.0 |
| thrml-beta-1 | 16 | 61/96 | 0.01753 | 224.0 | 0.0 |
| thrml-beta-1 | 64 | 87/96 | 0.00251 | 896.0 | 0.0 |
| thrml-beta-1 | 256 | 96/96 | 0.00000 | 3584.0 | 0.0 |
| thrml-beta-4 | 1 | 10/96 | 0.11461 | 14.0 | 0.0 |
| thrml-beta-4 | 4 | 29/96 | 0.05535 | 56.0 | 0.0 |
| thrml-beta-4 | 16 | 46/96 | 0.02954 | 224.0 | 0.0 |
| thrml-beta-4 | 64 | 59/96 | 0.01758 | 896.0 | 0.0 |
| thrml-beta-4 | 256 | 80/96 | 0.00723 | 3584.0 | 0.0 |
| restart-greedy | 1 | 9/96 | 0.12627 | 14.0 | 0.0 |
| restart-greedy | 4 | 26/96 | 0.06135 | 56.0 | 0.9 |
| restart-greedy | 16 | 63/96 | 0.01851 | 224.0 | 5.3 |
| restart-greedy | 64 | 93/96 | 0.00058 | 896.0 | 23.3 |
| restart-greedy | 256 | 96/96 | 0.00000 | 3584.0 | 95.1 |

## Per-graph results at the full budget

| Graph | Exact optimum | Restart greedy hits / 16 | THRML beta 1 hits / 16 | Annealing hits / 16 | Restart greedy CPU batch seconds |
|---|---:|---:|---:|---:|---:|
| n12-g0 | 48 | 16/16 | 16/16 | 16/16 | 0.074135 |
| n12-g1 | 49 | 16/16 | 16/16 | 16/16 | 0.070932 |
| n12-g2 | 53 | 16/16 | 16/16 | 16/16 | 0.071867 |
| n16-g0 | 54 | 16/16 | 16/16 | 16/16 | 0.091293 |
| n16-g1 | 64 | 16/16 | 16/16 | 16/16 | 0.089891 |
| n16-g2 | 77 | 16/16 | 16/16 | 16/16 | 0.087874 |

## Interpretation and limits

Budgets match attempted vertex updates, not equal wall time, RNG cost, energy or device operations. Greedy additionally generates and writes n random initialization bits at every restart; these counts are recorded separately. The original single-start greedy stops early and spends much less work. Gibbs redraws and greedy gain tests differ computationally.

Source THRML/annealing results are reused, not regenerated. Annealing's short-budget points are prefixes of its original 256-sweep temperature ramp; schedules are not tuned separately for each budget. All three source THRML temperatures are displayed. The moderate temperature was identified on these same graphs, so this is exploratory, not held-out evidence.

CPU batch timings are observations for this Python/NumPy implementation and include restart generation, gain computations and trace recording for 16 runs. Initialization copying is included; exact enumeration, source replay and final metric extraction are excluded. Do not interpret timings against JAX launches with different timed scopes as algorithmic speedups.

All heuristic/sampler outcomes are software_simulation and optima exact_reference. Six small graphs from one family do not establish scaling. Replay authenticates source artifacts, recomputes all old/new quality and work metrics, and regenerates every new baseline trajectory. Full per-run details and additional random-bit counts are in results.json; traces are separately hashed.
